# PathFinder-PRM Reproduction Project — Training Data Description

Here are four sets of training-format data (0/1/2/4-class error-label granularities), along with a recommended validation set split.

## 1. What This Is

The same 2,330 samples (1,165 erroneous steps + 1,165 correct/suboptimal steps), organized into four training datasets by four error-label granularities:

| Version | Rows per sample | Total rows in file | Label meaning (one sentence) |
|---|---:|---:|---|
| 0class | 1 (single stage) | 2330 | Only predict whether this step is ultimately correct (Correctness), without distinguishing error types. **Optional baseline**; whether to use it for training is up to you. |
| 1class | 2 (two stages) | 4660 | First predict whether this step contains any error (Error), then predict Correctness based on that. |
| 2class | 2 (two stages) | 4660 | First predict two dimensions — Math reasoning (calculation/method errors) and Consistency (prior-step/domain consistency errors) — then predict Correctness. |
| 4class | 2 (two stages) | 4660 | First predict four dimensions — Calculation, Method, Prior-step consistency, Domain consistency — then predict Correctness. |

## 2. File Listing

| File | Contents |
|---|---|
| `prm_0class.jsonl` | 0-class training data |
| `prm_1class.jsonl` | 1-class training data |
| `prm_2class.jsonl` | 2-class training data |
| `prm_4class.jsonl` | 4-class training data |
| `val_question_ids.json` | Recommended validation set question split (grouped by question, shared across all four versions) |

## 3. Per-Row Structure

Each row is a JSON object containing two conversation fields and several metadata fields:

- `labels`: The complete target sequence used during training, containing 1 user turn + 1 assistant turn. All labels in the assistant content are **known ground-truth tokens**.
- `inputs`: The version the model sees during inference, with the same structure, but **the label to be predicted** is replaced by the placeholder `<extra>`.

Metadata fields:

| Field | Meaning |
|---|---|
| `id` | Unique identifier for this row, format `{record_id}_{version}_{stage}` |
| `record_id` | Unique ID of this step in the expanded PRM800K |
| `question_id` | Question ID (first 12 characters of the SHA-1 of the question text); the same question shares the same ID across all versions and all rows; use this to group/split the dataset |
| `side` | `error` (erroneous step) or `correct` (correct/suboptimal step) |
| `human_score` | Original PRM800K human annotation: 1=correct, 0=suboptimal, -1=erroneous |
| `version` | `0class`/`1class`/`2class`/`4class` |
| `stage` | 0class is always `"single"`; 1/2/4class use `1` (stage 1) or `2` (stage 2) |

One real sample per version (from the actual generated files, `labels` field):

**0class** (`1428_0class_single`):

```json
{
  "labels": [
    {
      "role": "user",
      "content": "You are a Math Teacher. Given a question and a student's solution, evaluate whether the current step will lead to the correct final solution\n\n Question: Regular octagon $A_1A_2A_3A_4A_5A_6A_7A_8$ is inscribed in a circle of area $1.$ Point $P$ lies inside the circle so that the region bounded by $\\overline{PA_1},\\overline{PA_2},$ and the minor arc $\\widehat{A_1A_2}$ of the circle has area $\\tfrac{1}{7},$ while the region bounded by $\\overline{PA_3},\\overline{PA_4},$ and the minor arc $\\widehat{A_3A_4}$ of the circle has area $\\tfrac{1}{9}.$ There is a positive integer $n$ such that the area of the region bounded by $\\overline{PA_6},\\overline{PA_7},$ and the minor arc $\\widehat{A_6A_7}$ of the circle is equal to $\\tfrac{1}{8}-\\tfrac{\\sqrt2}{n}.$ Find $n.$"
    },
    {
      "role": "assistant",
      "content": "To start, we can compute the area bounded by the side of the octagon with the minor arc that it subtends\n\nThis would be the area of the sector of the circle minus the area of the triangle formed by the center of the circle and the two endpoints of the side of the octagon.\n\nYeah. And since an octagon has eight sides, we can divide the circle into eight equal sectors.\n\nAnd we know that the area of the circle is 1, so each sector has area $\\frac{1}{8}$.\n\nNow we have to find the area of the triangle.\n\nWe can split the triangle into two right triangles by drawing a line from the center of the circle to the midpoint of the side of the octagon.\n\nThat's true. And we know that the hypotenuse of each right triangle is the radius of the circle.\n\nAnd since the area of the circle is 1, the radius of the circle is $\\sqrt{\\frac{1}{\\pi}}$.\n\nThe central angle of the sector that coincides with the sides of the isoceles triangle has measure $\\frac{2\\pi}{8}$\n\nSo the right triangle has an angle at the center of the octagon that measures $\\frac{\\pi}{8}$\n\nIf we draw a line from the center of the circle to one of the vertices of the octagon, we can see that the right triangle has a leg of length $\\sqrt{\\frac{1}{\\pi}}$ and an angle of $\\frac{\\pi}{8}$.\n\nWe have a correction, the hypothenuse of the right triangle has length $\\sqrt{\\frac{1}{\\pi}}$ , not a leg of the right triangle\n\nSo the right triangle's side that is adjacent to the angle measuring $\\frac{\\pi}{8}$ has length $(\\cos \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}}$\n\nAnd the right triangle's side that is opposite to the angle measuring $\\frac{\\pi}{8}$ has length $(\\sin \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}}$\n\nSo the right triangle has area $\\frac{1}{2}((\\cos \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})((\\sin \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})$\n\nAnd since there are two of these right triangles, the area of the central triangle is $((\\cos \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})((\\sin \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})$\n\nSo the area of the region bounded by the side of the octagon and the minor arc it subtends is $\\frac{1}{8} - ((\\cos \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})((\\sin \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})$\n\nWe can use the identity $\\sin 2x = 2(\\sin x)( \\cos x)$ to evaluate $(\\sin \\frac{\\pi}{8})(\\cos \\frac{\\pi}{8})$\n\nYeah. This is equal to $\\frac{1}{2}(\\sin \\frac{\\pi}{4}) = \\frac{1}{2} \\cdot \\frac{\\sqrt{2}}{2} = \\frac{\\sqrt{2}}{4}$\n\nThen the area of the region bounded by the side of the octagon and the minor arc it subtends is $\\frac{1}{8} - \\frac{\\sqrt{2}}{4}(\\frac{1}{\\pi})$\n\nCurrent Step: Right. So the area of the region bounded by the side of the octagon and the minor arc it subtends is $\\frac{1}{8} - \\frac{\\sqrt{2}}{4}(\\frac{1}{\\pi})$ Correctness: <->"
    }
  ],
  "inputs": [
    {
      "role": "user",
      "content": "You are a Math Teacher. Given a question and a student's solution, evaluate whether the current step will lead to the correct final solution\n\n Question: Regular octagon $A_1A_2A_3A_4A_5A_6A_7A_8$ is inscribed in a circle of area $1.$ Point $P$ lies inside the circle so that the region bounded by $\\overline{PA_1},\\overline{PA_2},$ and the minor arc $\\widehat{A_1A_2}$ of the circle has area $\\tfrac{1}{7},$ while the region bounded by $\\overline{PA_3},\\overline{PA_4},$ and the minor arc $\\widehat{A_3A_4}$ of the circle has area $\\tfrac{1}{9}.$ There is a positive integer $n$ such that the area of the region bounded by $\\overline{PA_6},\\overline{PA_7},$ and the minor arc $\\widehat{A_6A_7}$ of the circle is equal to $\\tfrac{1}{8}-\\tfrac{\\sqrt2}{n}.$ Find $n.$"
    },
    {
      "role": "assistant",
      "content": "To start, we can compute the area bounded by the side of the octagon with the minor arc that it subtends\n\nThis would be the area of the sector of the circle minus the area of the triangle formed by the center of the circle and the two endpoints of the side of the octagon.\n\nYeah. And since an octagon has eight sides, we can divide the circle into eight equal sectors.\n\nAnd we know that the area of the circle is 1, so each sector has area $\\frac{1}{8}$.\n\nNow we have to find the area of the triangle.\n\nWe can split the triangle into two right triangles by drawing a line from the center of the circle to the midpoint of the side of the octagon.\n\nThat's true. And we know that the hypotenuse of each right triangle is the radius of the circle.\n\nAnd since the area of the circle is 1, the radius of the circle is $\\sqrt{\\frac{1}{\\pi}}$.\n\nThe central angle of the sector that coincides with the sides of the isoceles triangle has measure $\\frac{2\\pi}{8}$\n\nSo the right triangle has an angle at the center of the octagon that measures $\\frac{\\pi}{8}$\n\nIf we draw a line from the center of the circle to one of the vertices of the octagon, we can see that the right triangle has a leg of length $\\sqrt{\\frac{1}{\\pi}}$ and an angle of $\\frac{\\pi}{8}$.\n\nWe have a correction, the hypothenuse of the right triangle has length $\\sqrt{\\frac{1}{\\pi}}$ , not a leg of the right triangle\n\nSo the right triangle's side that is adjacent to the angle measuring $\\frac{\\pi}{8}$ has length $(\\cos \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}}$\n\nAnd the right triangle's side that is opposite to the angle measuring $\\frac{\\pi}{8}$ has length $(\\sin \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}}$\n\nSo the right triangle has area $\\frac{1}{2}((\\cos \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})((\\sin \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})$\n\nAnd since there are two of these right triangles, the area of the central triangle is $((\\cos \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})((\\sin \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})$\n\nSo the area of the region bounded by the side of the octagon and the minor arc it subtends is $\\frac{1}{8} - ((\\cos \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})((\\sin \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})$\n\nWe can use the identity $\\sin 2x = 2(\\sin x)( \\cos x)$ to evaluate $(\\sin \\frac{\\pi}{8})(\\cos \\frac{\\pi}{8})$\n\nYeah. This is equal to $\\frac{1}{2}(\\sin \\frac{\\pi}{4}) = \\frac{1}{2} \\cdot \\frac{\\sqrt{2}}{2} = \\frac{\\sqrt{2}}{4}$\n\nThen the area of the region bounded by the side of the octagon and the minor arc it subtends is $\\frac{1}{8} - \\frac{\\sqrt{2}}{4}(\\frac{1}{\\pi})$\n\nCurrent Step: Right. So the area of the region bounded by the side of the octagon and the minor arc it subtends is $\\frac{1}{8} - \\frac{\\sqrt{2}}{4}(\\frac{1}{\\pi})$ Correctness: <extra>"
    }
  ],
  "id": "1428_0class_single",
  "record_id": 1428,
  "question_id": "3b1ff4062ef6",
  "side": "correct",
  "human_score": 0,
  "version": "0class",
  "stage": "single"
}
```

**1class** (`1428_1class_1`):

```json
{
  "labels": [
    {
      "role": "user",
      "content": "You are a Math Teacher. Given a question and a student's solution, evaluate whether the current step contains any error and whether it will lead to the correct final solution\n\n Question: Regular octagon $A_1A_2A_3A_4A_5A_6A_7A_8$ is inscribed in a circle of area $1.$ Point $P$ lies inside the circle so that the region bounded by $\\overline{PA_1},\\overline{PA_2},$ and the minor arc $\\widehat{A_1A_2}$ of the circle has area $\\tfrac{1}{7},$ while the region bounded by $\\overline{PA_3},\\overline{PA_4},$ and the minor arc $\\widehat{A_3A_4}$ of the circle has area $\\tfrac{1}{9}.$ There is a positive integer $n$ such that the area of the region bounded by $\\overline{PA_6},\\overline{PA_7},$ and the minor arc $\\widehat{A_6A_7}$ of the circle is equal to $\\tfrac{1}{8}-\\tfrac{\\sqrt2}{n}.$ Find $n.$"
    },
    {
      "role": "assistant",
      "content": "To start, we can compute the area bounded by the side of the octagon with the minor arc that it subtends\n\nThis would be the area of the sector of the circle minus the area of the triangle formed by the center of the circle and the two endpoints of the side of the octagon.\n\nYeah. And since an octagon has eight sides, we can divide the circle into eight equal sectors.\n\nAnd we know that the area of the circle is 1, so each sector has area $\\frac{1}{8}$.\n\nNow we have to find the area of the triangle.\n\nWe can split the triangle into two right triangles by drawing a line from the center of the circle to the midpoint of the side of the octagon.\n\nThat's true. And we know that the hypotenuse of each right triangle is the radius of the circle.\n\nAnd since the area of the circle is 1, the radius of the circle is $\\sqrt{\\frac{1}{\\pi}}$.\n\nThe central angle of the sector that coincides with the sides of the isoceles triangle has measure $\\frac{2\\pi}{8}$\n\nSo the right triangle has an angle at the center of the octagon that measures $\\frac{\\pi}{8}$\n\nIf we draw a line from the center of the circle to one of the vertices of the octagon, we can see that the right triangle has a leg of length $\\sqrt{\\frac{1}{\\pi}}$ and an angle of $\\frac{\\pi}{8}$.\n\nWe have a correction, the hypothenuse of the right triangle has length $\\sqrt{\\frac{1}{\\pi}}$ , not a leg of the right triangle\n\nSo the right triangle's side that is adjacent to the angle measuring $\\frac{\\pi}{8}$ has length $(\\cos \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}}$\n\nAnd the right triangle's side that is opposite to the angle measuring $\\frac{\\pi}{8}$ has length $(\\sin \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}}$\n\nSo the right triangle has area $\\frac{1}{2}((\\cos \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})((\\sin \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})$\n\nAnd since there are two of these right triangles, the area of the central triangle is $((\\cos \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})((\\sin \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})$\n\nSo the area of the region bounded by the side of the octagon and the minor arc it subtends is $\\frac{1}{8} - ((\\cos \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})((\\sin \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})$\n\nWe can use the identity $\\sin 2x = 2(\\sin x)( \\cos x)$ to evaluate $(\\sin \\frac{\\pi}{8})(\\cos \\frac{\\pi}{8})$\n\nYeah. This is equal to $\\frac{1}{2}(\\sin \\frac{\\pi}{4}) = \\frac{1}{2} \\cdot \\frac{\\sqrt{2}}{2} = \\frac{\\sqrt{2}}{4}$\n\nThen the area of the region bounded by the side of the octagon and the minor arc it subtends is $\\frac{1}{8} - \\frac{\\sqrt{2}}{4}(\\frac{1}{\\pi})$\n\nCurrent Step: Right. So the area of the region bounded by the side of the octagon and the minor arc it subtends is $\\frac{1}{8} - \\frac{\\sqrt{2}}{4}(\\frac{1}{\\pi})$ Error: <+>"
    }
  ],
  "inputs": [
    {
      "role": "user",
      "content": "You are a Math Teacher. Given a question and a student's solution, evaluate whether the current step contains any error and whether it will lead to the correct final solution\n\n Question: Regular octagon $A_1A_2A_3A_4A_5A_6A_7A_8$ is inscribed in a circle of area $1.$ Point $P$ lies inside the circle so that the region bounded by $\\overline{PA_1},\\overline{PA_2},$ and the minor arc $\\widehat{A_1A_2}$ of the circle has area $\\tfrac{1}{7},$ while the region bounded by $\\overline{PA_3},\\overline{PA_4},$ and the minor arc $\\widehat{A_3A_4}$ of the circle has area $\\tfrac{1}{9}.$ There is a positive integer $n$ such that the area of the region bounded by $\\overline{PA_6},\\overline{PA_7},$ and the minor arc $\\widehat{A_6A_7}$ of the circle is equal to $\\tfrac{1}{8}-\\tfrac{\\sqrt2}{n}.$ Find $n.$"
    },
    {
      "role": "assistant",
      "content": "To start, we can compute the area bounded by the side of the octagon with the minor arc that it subtends\n\nThis would be the area of the sector of the circle minus the area of the triangle formed by the center of the circle and the two endpoints of the side of the octagon.\n\nYeah. And since an octagon has eight sides, we can divide the circle into eight equal sectors.\n\nAnd we know that the area of the circle is 1, so each sector has area $\\frac{1}{8}$.\n\nNow we have to find the area of the triangle.\n\nWe can split the triangle into two right triangles by drawing a line from the center of the circle to the midpoint of the side of the octagon.\n\nThat's true. And we know that the hypotenuse of each right triangle is the radius of the circle.\n\nAnd since the area of the circle is 1, the radius of the circle is $\\sqrt{\\frac{1}{\\pi}}$.\n\nThe central angle of the sector that coincides with the sides of the isoceles triangle has measure $\\frac{2\\pi}{8}$\n\nSo the right triangle has an angle at the center of the octagon that measures $\\frac{\\pi}{8}$\n\nIf we draw a line from the center of the circle to one of the vertices of the octagon, we can see that the right triangle has a leg of length $\\sqrt{\\frac{1}{\\pi}}$ and an angle of $\\frac{\\pi}{8}$.\n\nWe have a correction, the hypothenuse of the right triangle has length $\\sqrt{\\frac{1}{\\pi}}$ , not a leg of the right triangle\n\nSo the right triangle's side that is adjacent to the angle measuring $\\frac{\\pi}{8}$ has length $(\\cos \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}}$\n\nAnd the right triangle's side that is opposite to the angle measuring $\\frac{\\pi}{8}$ has length $(\\sin \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}}$\n\nSo the right triangle has area $\\frac{1}{2}((\\cos \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})((\\sin \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})$\n\nAnd since there are two of these right triangles, the area of the central triangle is $((\\cos \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})((\\sin \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})$\n\nSo the area of the region bounded by the side of the octagon and the minor arc it subtends is $\\frac{1}{8} - ((\\cos \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})((\\sin \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})$\n\nWe can use the identity $\\sin 2x = 2(\\sin x)( \\cos x)$ to evaluate $(\\sin \\frac{\\pi}{8})(\\cos \\frac{\\pi}{8})$\n\nYeah. This is equal to $\\frac{1}{2}(\\sin \\frac{\\pi}{4}) = \\frac{1}{2} \\cdot \\frac{\\sqrt{2}}{2} = \\frac{\\sqrt{2}}{4}$\n\nThen the area of the region bounded by the side of the octagon and the minor arc it subtends is $\\frac{1}{8} - \\frac{\\sqrt{2}}{4}(\\frac{1}{\\pi})$\n\nCurrent Step: Right. So the area of the region bounded by the side of the octagon and the minor arc it subtends is $\\frac{1}{8} - \\frac{\\sqrt{2}}{4}(\\frac{1}{\\pi})$ Error: <extra>"
    }
  ],
  "id": "1428_1class_1",
  "record_id": 1428,
  "question_id": "3b1ff4062ef6",
  "side": "correct",
  "human_score": 0,
  "version": "1class",
  "stage": 1
}
```

**2class** (`1428_2class_1`):

```json
{
  "labels": [
    {
      "role": "user",
      "content": "You are a Math Teacher. Given a question and a student's solution, evaluate the mathematical correctness, logic consistency of the current step and whether it will lead to the correct final solution\n\n Question: Regular octagon $A_1A_2A_3A_4A_5A_6A_7A_8$ is inscribed in a circle of area $1.$ Point $P$ lies inside the circle so that the region bounded by $\\overline{PA_1},\\overline{PA_2},$ and the minor arc $\\widehat{A_1A_2}$ of the circle has area $\\tfrac{1}{7},$ while the region bounded by $\\overline{PA_3},\\overline{PA_4},$ and the minor arc $\\widehat{A_3A_4}$ of the circle has area $\\tfrac{1}{9}.$ There is a positive integer $n$ such that the area of the region bounded by $\\overline{PA_6},\\overline{PA_7},$ and the minor arc $\\widehat{A_6A_7}$ of the circle is equal to $\\tfrac{1}{8}-\\tfrac{\\sqrt2}{n}.$ Find $n.$"
    },
    {
      "role": "assistant",
      "content": "To start, we can compute the area bounded by the side of the octagon with the minor arc that it subtends\n\nThis would be the area of the sector of the circle minus the area of the triangle formed by the center of the circle and the two endpoints of the side of the octagon.\n\nYeah. And since an octagon has eight sides, we can divide the circle into eight equal sectors.\n\nAnd we know that the area of the circle is 1, so each sector has area $\\frac{1}{8}$.\n\nNow we have to find the area of the triangle.\n\nWe can split the triangle into two right triangles by drawing a line from the center of the circle to the midpoint of the side of the octagon.\n\nThat's true. And we know that the hypotenuse of each right triangle is the radius of the circle.\n\nAnd since the area of the circle is 1, the radius of the circle is $\\sqrt{\\frac{1}{\\pi}}$.\n\nThe central angle of the sector that coincides with the sides of the isoceles triangle has measure $\\frac{2\\pi}{8}$\n\nSo the right triangle has an angle at the center of the octagon that measures $\\frac{\\pi}{8}$\n\nIf we draw a line from the center of the circle to one of the vertices of the octagon, we can see that the right triangle has a leg of length $\\sqrt{\\frac{1}{\\pi}}$ and an angle of $\\frac{\\pi}{8}$.\n\nWe have a correction, the hypothenuse of the right triangle has length $\\sqrt{\\frac{1}{\\pi}}$ , not a leg of the right triangle\n\nSo the right triangle's side that is adjacent to the angle measuring $\\frac{\\pi}{8}$ has length $(\\cos \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}}$\n\nAnd the right triangle's side that is opposite to the angle measuring $\\frac{\\pi}{8}$ has length $(\\sin \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}}$\n\nSo the right triangle has area $\\frac{1}{2}((\\cos \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})((\\sin \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})$\n\nAnd since there are two of these right triangles, the area of the central triangle is $((\\cos \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})((\\sin \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})$\n\nSo the area of the region bounded by the side of the octagon and the minor arc it subtends is $\\frac{1}{8} - ((\\cos \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})((\\sin \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})$\n\nWe can use the identity $\\sin 2x = 2(\\sin x)( \\cos x)$ to evaluate $(\\sin \\frac{\\pi}{8})(\\cos \\frac{\\pi}{8})$\n\nYeah. This is equal to $\\frac{1}{2}(\\sin \\frac{\\pi}{4}) = \\frac{1}{2} \\cdot \\frac{\\sqrt{2}}{2} = \\frac{\\sqrt{2}}{4}$\n\nThen the area of the region bounded by the side of the octagon and the minor arc it subtends is $\\frac{1}{8} - \\frac{\\sqrt{2}}{4}(\\frac{1}{\\pi})$\n\nCurrent Step: Right. So the area of the region bounded by the side of the octagon and the minor arc it subtends is $\\frac{1}{8} - \\frac{\\sqrt{2}}{4}(\\frac{1}{\\pi})$ Math reasoning: <+>, Consistency: <+>"
    }
  ],
  "inputs": [
    {
      "role": "user",
      "content": "You are a Math Teacher. Given a question and a student's solution, evaluate the mathematical correctness, logic consistency of the current step and whether it will lead to the correct final solution\n\n Question: Regular octagon $A_1A_2A_3A_4A_5A_6A_7A_8$ is inscribed in a circle of area $1.$ Point $P$ lies inside the circle so that the region bounded by $\\overline{PA_1},\\overline{PA_2},$ and the minor arc $\\widehat{A_1A_2}$ of the circle has area $\\tfrac{1}{7},$ while the region bounded by $\\overline{PA_3},\\overline{PA_4},$ and the minor arc $\\widehat{A_3A_4}$ of the circle has area $\\tfrac{1}{9}.$ There is a positive integer $n$ such that the area of the region bounded by $\\overline{PA_6},\\overline{PA_7},$ and the minor arc $\\widehat{A_6A_7}$ of the circle is equal to $\\tfrac{1}{8}-\\tfrac{\\sqrt2}{n}.$ Find $n.$"
    },
    {
      "role": "assistant",
      "content": "To start, we can compute the area bounded by the side of the octagon with the minor arc that it subtends\n\nThis would be the area of the sector of the circle minus the area of the triangle formed by the center of the circle and the two endpoints of the side of the octagon.\n\nYeah. And since an octagon has eight sides, we can divide the circle into eight equal sectors.\n\nAnd we know that the area of the circle is 1, so each sector has area $\\frac{1}{8}$.\n\nNow we have to find the area of the triangle.\n\nWe can split the triangle into two right triangles by drawing a line from the center of the circle to the midpoint of the side of the octagon.\n\nThat's true. And we know that the hypotenuse of each right triangle is the radius of the circle.\n\nAnd since the area of the circle is 1, the radius of the circle is $\\sqrt{\\frac{1}{\\pi}}$.\n\nThe central angle of the sector that coincides with the sides of the isoceles triangle has measure $\\frac{2\\pi}{8}$\n\nSo the right triangle has an angle at the center of the octagon that measures $\\frac{\\pi}{8}$\n\nIf we draw a line from the center of the circle to one of the vertices of the octagon, we can see that the right triangle has a leg of length $\\sqrt{\\frac{1}{\\pi}}$ and an angle of $\\frac{\\pi}{8}$.\n\nWe have a correction, the hypothenuse of the right triangle has length $\\sqrt{\\frac{1}{\\pi}}$ , not a leg of the right triangle\n\nSo the right triangle's side that is adjacent to the angle measuring $\\frac{\\pi}{8}$ has length $(\\cos \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}}$\n\nAnd the right triangle's side that is opposite to the angle measuring $\\frac{\\pi}{8}$ has length $(\\sin \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}}$\n\nSo the right triangle has area $\\frac{1}{2}((\\cos \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})((\\sin \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})$\n\nAnd since there are two of these right triangles, the area of the central triangle is $((\\cos \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})((\\sin \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})$\n\nSo the area of the region bounded by the side of the octagon and the minor arc it subtends is $\\frac{1}{8} - ((\\cos \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})((\\sin \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})$\n\nWe can use the identity $\\sin 2x = 2(\\sin x)( \\cos x)$ to evaluate $(\\sin \\frac{\\pi}{8})(\\cos \\frac{\\pi}{8})$\n\nYeah. This is equal to $\\frac{1}{2}(\\sin \\frac{\\pi}{4}) = \\frac{1}{2} \\cdot \\frac{\\sqrt{2}}{2} = \\frac{\\sqrt{2}}{4}$\n\nThen the area of the region bounded by the side of the octagon and the minor arc it subtends is $\\frac{1}{8} - \\frac{\\sqrt{2}}{4}(\\frac{1}{\\pi})$\n\nCurrent Step: Right. So the area of the region bounded by the side of the octagon and the minor arc it subtends is $\\frac{1}{8} - \\frac{\\sqrt{2}}{4}(\\frac{1}{\\pi})$ Math reasoning: <extra>, Consistency: <extra>"
    }
  ],
  "id": "1428_2class_1",
  "record_id": 1428,
  "question_id": "3b1ff4062ef6",
  "side": "correct",
  "human_score": 0,
  "version": "2class",
  "stage": 1
}
```

**4class** (`1428_4class_1`):

```json
{
  "labels": [
    {
      "role": "user",
      "content": "You are a Math Teacher. Given a question and a student's solution, evaluate the calculation correctness, method validity, consistency with prior steps, and consistency with the problem domain of the current step and whether it will lead to the correct final solution\n\n Question: Regular octagon $A_1A_2A_3A_4A_5A_6A_7A_8$ is inscribed in a circle of area $1.$ Point $P$ lies inside the circle so that the region bounded by $\\overline{PA_1},\\overline{PA_2},$ and the minor arc $\\widehat{A_1A_2}$ of the circle has area $\\tfrac{1}{7},$ while the region bounded by $\\overline{PA_3},\\overline{PA_4},$ and the minor arc $\\widehat{A_3A_4}$ of the circle has area $\\tfrac{1}{9}.$ There is a positive integer $n$ such that the area of the region bounded by $\\overline{PA_6},\\overline{PA_7},$ and the minor arc $\\widehat{A_6A_7}$ of the circle is equal to $\\tfrac{1}{8}-\\tfrac{\\sqrt2}{n}.$ Find $n.$"
    },
    {
      "role": "assistant",
      "content": "To start, we can compute the area bounded by the side of the octagon with the minor arc that it subtends\n\nThis would be the area of the sector of the circle minus the area of the triangle formed by the center of the circle and the two endpoints of the side of the octagon.\n\nYeah. And since an octagon has eight sides, we can divide the circle into eight equal sectors.\n\nAnd we know that the area of the circle is 1, so each sector has area $\\frac{1}{8}$.\n\nNow we have to find the area of the triangle.\n\nWe can split the triangle into two right triangles by drawing a line from the center of the circle to the midpoint of the side of the octagon.\n\nThat's true. And we know that the hypotenuse of each right triangle is the radius of the circle.\n\nAnd since the area of the circle is 1, the radius of the circle is $\\sqrt{\\frac{1}{\\pi}}$.\n\nThe central angle of the sector that coincides with the sides of the isoceles triangle has measure $\\frac{2\\pi}{8}$\n\nSo the right triangle has an angle at the center of the octagon that measures $\\frac{\\pi}{8}$\n\nIf we draw a line from the center of the circle to one of the vertices of the octagon, we can see that the right triangle has a leg of length $\\sqrt{\\frac{1}{\\pi}}$ and an angle of $\\frac{\\pi}{8}$.\n\nWe have a correction, the hypothenuse of the right triangle has length $\\sqrt{\\frac{1}{\\pi}}$ , not a leg of the right triangle\n\nSo the right triangle's side that is adjacent to the angle measuring $\\frac{\\pi}{8}$ has length $(\\cos \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}}$\n\nAnd the right triangle's side that is opposite to the angle measuring $\\frac{\\pi}{8}$ has length $(\\sin \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}}$\n\nSo the right triangle has area $\\frac{1}{2}((\\cos \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})((\\sin \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})$\n\nAnd since there are two of these right triangles, the area of the central triangle is $((\\cos \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})((\\sin \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})$\n\nSo the area of the region bounded by the side of the octagon and the minor arc it subtends is $\\frac{1}{8} - ((\\cos \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})((\\sin \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})$\n\nWe can use the identity $\\sin 2x = 2(\\sin x)( \\cos x)$ to evaluate $(\\sin \\frac{\\pi}{8})(\\cos \\frac{\\pi}{8})$\n\nYeah. This is equal to $\\frac{1}{2}(\\sin \\frac{\\pi}{4}) = \\frac{1}{2} \\cdot \\frac{\\sqrt{2}}{2} = \\frac{\\sqrt{2}}{4}$\n\nThen the area of the region bounded by the side of the octagon and the minor arc it subtends is $\\frac{1}{8} - \\frac{\\sqrt{2}}{4}(\\frac{1}{\\pi})$\n\nCurrent Step: Right. So the area of the region bounded by the side of the octagon and the minor arc it subtends is $\\frac{1}{8} - \\frac{\\sqrt{2}}{4}(\\frac{1}{\\pi})$ Calculation: <+>, Method: <+>, Prior-step consistency: <+>, Domain consistency: <+>"
    }
  ],
  "inputs": [
    {
      "role": "user",
      "content": "You are a Math Teacher. Given a question and a student's solution, evaluate the calculation correctness, method validity, consistency with prior steps, and consistency with the problem domain of the current step and whether it will lead to the correct final solution\n\n Question: Regular octagon $A_1A_2A_3A_4A_5A_6A_7A_8$ is inscribed in a circle of area $1.$ Point $P$ lies inside the circle so that the region bounded by $\\overline{PA_1},\\overline{PA_2},$ and the minor arc $\\widehat{A_1A_2}$ of the circle has area $\\tfrac{1}{7},$ while the region bounded by $\\overline{PA_3},\\overline{PA_4},$ and the minor arc $\\widehat{A_3A_4}$ of the circle has area $\\tfrac{1}{9}.$ There is a positive integer $n$ such that the area of the region bounded by $\\overline{PA_6},\\overline{PA_7},$ and the minor arc $\\widehat{A_6A_7}$ of the circle is equal to $\\tfrac{1}{8}-\\tfrac{\\sqrt2}{n}.$ Find $n.$"
    },
    {
      "role": "assistant",
      "content": "To start, we can compute the area bounded by the side of the octagon with the minor arc that it subtends\n\nThis would be the area of the sector of the circle minus the area of the triangle formed by the center of the circle and the two endpoints of the side of the octagon.\n\nYeah. And since an octagon has eight sides, we can divide the circle into eight equal sectors.\n\nAnd we know that the area of the circle is 1, so each sector has area $\\frac{1}{8}$.\n\nNow we have to find the area of the triangle.\n\nWe can split the triangle into two right triangles by drawing a line from the center of the circle to the midpoint of the side of the octagon.\n\nThat's true. And we know that the hypotenuse of each right triangle is the radius of the circle.\n\nAnd since the area of the circle is 1, the radius of the circle is $\\sqrt{\\frac{1}{\\pi}}$.\n\nThe central angle of the sector that coincides with the sides of the isoceles triangle has measure $\\frac{2\\pi}{8}$\n\nSo the right triangle has an angle at the center of the octagon that measures $\\frac{\\pi}{8}$\n\nIf we draw a line from the center of the circle to one of the vertices of the octagon, we can see that the right triangle has a leg of length $\\sqrt{\\frac{1}{\\pi}}$ and an angle of $\\frac{\\pi}{8}$.\n\nWe have a correction, the hypothenuse of the right triangle has length $\\sqrt{\\frac{1}{\\pi}}$ , not a leg of the right triangle\n\nSo the right triangle's side that is adjacent to the angle measuring $\\frac{\\pi}{8}$ has length $(\\cos \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}}$\n\nAnd the right triangle's side that is opposite to the angle measuring $\\frac{\\pi}{8}$ has length $(\\sin \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}}$\n\nSo the right triangle has area $\\frac{1}{2}((\\cos \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})((\\sin \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})$\n\nAnd since there are two of these right triangles, the area of the central triangle is $((\\cos \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})((\\sin \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})$\n\nSo the area of the region bounded by the side of the octagon and the minor arc it subtends is $\\frac{1}{8} - ((\\cos \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})((\\sin \\frac{\\pi}{8})\\sqrt{\\frac{1}{\\pi}})$\n\nWe can use the identity $\\sin 2x = 2(\\sin x)( \\cos x)$ to evaluate $(\\sin \\frac{\\pi}{8})(\\cos \\frac{\\pi}{8})$\n\nYeah. This is equal to $\\frac{1}{2}(\\sin \\frac{\\pi}{4}) = \\frac{1}{2} \\cdot \\frac{\\sqrt{2}}{2} = \\frac{\\sqrt{2}}{4}$\n\nThen the area of the region bounded by the side of the octagon and the minor arc it subtends is $\\frac{1}{8} - \\frac{\\sqrt{2}}{4}(\\frac{1}{\\pi})$\n\nCurrent Step: Right. So the area of the region bounded by the side of the octagon and the minor arc it subtends is $\\frac{1}{8} - \\frac{\\sqrt{2}}{4}(\\frac{1}{\\pi})$ Calculation: <extra>, Method: <extra>, Prior-step consistency: <extra>, Domain consistency: <extra>"
    }
  ],
  "id": "1428_4class_1",
  "record_id": 1428,
  "question_id": "3b1ff4062ef6",
  "side": "correct",
  "human_score": 0,
  "version": "4class",
  "stage": 1
}
```

## 4. Token Conventions

- `<+>` = no issue / correct for this dimension
- `<->` = issue / incorrect for this dimension
- `<extra>` = placeholder to be predicted (appears only in `inputs`)

Label string format (appended after the step text):

| Version | Stage-1 label string | Stage-2 label string (appended after stage 1) |
|---|---|---|
| 0class | No stage 1; directly `Correctness: {tok}` | None |
| 1class | `Error: {tok}` | `, Correctness: {tok}` |
| 2class | `Math reasoning: {tok}, Consistency: {tok}` | `, Correctness: {tok}` |
| 4class | `Calculation: {tok}, Method: {tok}, Prior-step consistency: {tok}, Domain consistency: {tok}` | `, Correctness: {tok}` |

Classes 1/2/4 use two stages (the same record corresponds to 2 adjacent rows in the file): the first row predicts only stage-1 labels; the second row treats stage-1 labels as known ground truth and predicts only Correctness. Class 0 is single-stage (1 record = 1 row), with only Correctness as the prediction target.

## 5. Validation Set

**No test set is included** — testing/evaluation uses PRMBench (see next section); the data here is for training and your own validation set only.

Recommended validation set split: group by `question_id`, randomly sample ~5% of questions (seed=42; 93 out of 1,852 questions, i.e., 5.0%), stored in the `val_question_ids` array in `val_question_ids.json`. **All four versions share the same split.** If each version creates its own split, the validation sets will no longer be aligned — please be aware of this when comparing.

Usage: when reading a version's JSONL file, compare each row's `question_id` against the set in `val_question_ids.json`; rows in the set go to the validation set, the rest to the training set. **All rows for the same question (including both stages of the same record, and any error-side/correct-side rows that happen to use the same question) will fall entirely on one side** — no question will be split across training and validation.

Row counts per version after this split:

| Version | Training rows | Validation rows |
|---|---:|---:|
| 0class | 2216 | 114 |
| 1class | 4432 | 228 |
| 2class | 4432 | 228 |
| 4class | 4432 | 228 |

## 6. What Evaluation Team Members Need to Know

### 6.1 What the Model Sees During Inference

The input the model sees during inference = the `inputs` field of each row:

- **User turn**: `system prompt + "\n\n Question: " + question text`
- **Assistant turn**: `previous steps (multiple steps separated by blank lines "\n\n") + "\n\nCurrent Step: " + current step + label string to be predicted (using <extra> placeholders)`; if this is the first step of the question (no previous steps), it is directly `"Current Step: " + current step + label string`.

Evaluation team members need to assemble each PRMBench question and each step in this format — **the format must exactly match the training format**, including: previous steps separated by blank lines, the literal prefix `Current Step:`, and the label string format for the corresponding version (see Section 4).

One real `inputs` example per version (from the actual generated files):

**0class** (`1428_0class_single`, assistant turn `inputs` content):

```text
To start, we can compute the area bounded by the side of the octagon with the minor arc that it subtends

This would be the area of the sector of the circle minus the area of the triangle formed by the center of the circle and the two endpoints of the side of the octagon.

Yeah. And since an octagon has eight sides, we can divide the circle into eight equal sectors.

And we know that the area of the circle is 1, so each sector has area $\frac{1}{8}$.

Now we have to find the area of the triangle.

We can split the triangle into two right triangles by drawing a line from the center of the circle to the midpoint of the side of the octagon.

That's true. And we know that the hypotenuse of each right triangle is the radius of the circle.

And since the area of the circle is 1, the radius of the circle is $\sqrt{\frac{1}{\pi}}$.

The central angle of the sector that coincides with the sides of the isoceles triangle has measure $\frac{2\pi}{8}$

So the right triangle has an angle at the center of the octagon that measures $\frac{\pi}{8}$

If we draw a line from the center of the circle to one of the vertices of the octagon, we can see that the right triangle has a leg of length $\sqrt{\frac{1}{\pi}}$ and an angle of $\frac{\pi}{8}$.

We have a correction, the hypothenuse of the right triangle has length $\sqrt{\frac{1}{\pi}}$ , not a leg of the right triangle

So the right triangle's side that is adjacent to the angle measuring $\frac{\pi}{8}$ has length $(\cos \frac{\pi}{8})\sqrt{\frac{1}{\pi}}$

And the right triangle's side that is opposite to the angle measuring $\frac{\pi}{8}$ has length $(\sin \frac{\pi}{8})\sqrt{\frac{1}{\pi}}$

So the right triangle has area $\frac{1}{2}((\cos \frac{\pi}{8})\sqrt{\frac{1}{\pi}})((\sin \frac{\pi}{8})\sqrt{\frac{1}{\pi}})$

And since there are two of these right triangles, the area of the central triangle is $((\cos \frac{\pi}{8})\sqrt{\frac{1}{\pi}})((\sin \frac{\pi}{8})\sqrt{\frac{1}{\pi}})$

So the area of the region bounded by the side of the octagon and the minor arc it subtends is $\frac{1}{8} - ((\cos \frac{\pi}{8})\sqrt{\frac{1}{\pi}})((\sin \frac{\pi}{8})\sqrt{\frac{1}{\pi}})$

We can use the identity $\sin 2x = 2(\sin x)( \cos x)$ to evaluate $(\sin \frac{\pi}{8})(\cos \frac{\pi}{8})$

Yeah. This is equal to $\frac{1}{2}(\sin \frac{\pi}{4}) = \frac{1}{2} \cdot \frac{\sqrt{2}}{2} = \frac{\sqrt{2}}{4}$

Then the area of the region bounded by the side of the octagon and the minor arc it subtends is $\frac{1}{8} - \frac{\sqrt{2}}{4}(\frac{1}{\pi})$

Current Step: Right. So the area of the region bounded by the side of the octagon and the minor arc it subtends is $\frac{1}{8} - \frac{\sqrt{2}}{4}(\frac{1}{\pi})$ Correctness: <extra>
```

**1class** (`1428_1class_1`, assistant turn `inputs` content):

```text
To start, we can compute the area bounded by the side of the octagon with the minor arc that it subtends

This would be the area of the sector of the circle minus the area of the triangle formed by the center of the circle and the two endpoints of the side of the octagon.

Yeah. And since an octagon has eight sides, we can divide the circle into eight equal sectors.

And we know that the area of the circle is 1, so each sector has area $\frac{1}{8}$.

Now we have to find the area of the triangle.

We can split the triangle into two right triangles by drawing a line from the center of the circle to the midpoint of the side of the octagon.

That's true. And we know that the hypotenuse of each right triangle is the radius of the circle.

And since the area of the circle is 1, the radius of the circle is $\sqrt{\frac{1}{\pi}}$.

The central angle of the sector that coincides with the sides of the isoceles triangle has measure $\frac{2\pi}{8}$

So the right triangle has an angle at the center of the octagon that measures $\frac{\pi}{8}$

If we draw a line from the center of the circle to one of the vertices of the octagon, we can see that the right triangle has a leg of length $\sqrt{\frac{1}{\pi}}$ and an angle of $\frac{\pi}{8}$.

We have a correction, the hypothenuse of the right triangle has length $\sqrt{\frac{1}{\pi}}$ , not a leg of the right triangle

So the right triangle's side that is adjacent to the angle measuring $\frac{\pi}{8}$ has length $(\cos \frac{\pi}{8})\sqrt{\frac{1}{\pi}}$

And the right triangle's side that is opposite to the angle measuring $\frac{\pi}{8}$ has length $(\sin \frac{\pi}{8})\sqrt{\frac{1}{\pi}}$

So the right triangle has area $\frac{1}{2}((\cos \frac{\pi}{8})\sqrt{\frac{1}{\pi}})((\sin \frac{\pi}{8})\sqrt{\frac{1}{\pi}})$

And since there are two of these right triangles, the area of the central triangle is $((\cos \frac{\pi}{8})\sqrt{\frac{1}{\pi}})((\sin \frac{\pi}{8})\sqrt{\frac{1}{\pi}})$

So the area of the region bounded by the side of the octagon and the minor arc it subtends is $\frac{1}{8} - ((\cos \frac{\pi}{8})\sqrt{\frac{1}{\pi}})((\sin \frac{\pi}{8})\sqrt{\frac{1}{\pi}})$

We can use the identity $\sin 2x = 2(\sin x)( \cos x)$ to evaluate $(\sin \frac{\pi}{8})(\cos \frac{\pi}{8})$

Yeah. This is equal to $\frac{1}{2}(\sin \frac{\pi}{4}) = \frac{1}{2} \cdot \frac{\sqrt{2}}{2} = \frac{\sqrt{2}}{4}$

Then the area of the region bounded by the side of the octagon and the minor arc it subtends is $\frac{1}{8} - \frac{\sqrt{2}}{4}(\frac{1}{\pi})$

Current Step: Right. So the area of the region bounded by the side of the octagon and the minor arc it subtends is $\frac{1}{8} - \frac{\sqrt{2}}{4}(\frac{1}{\pi})$ Error: <extra>
```

**2class** (`1428_2class_1`, assistant turn `inputs` content):

```text
To start, we can compute the area bounded by the side of the octagon with the minor arc that it subtends

This would be the area of the sector of the circle minus the area of the triangle formed by the center of the circle and the two endpoints of the side of the octagon.

Yeah. And since an octagon has eight sides, we can divide the circle into eight equal sectors.

And we know that the area of the circle is 1, so each sector has area $\frac{1}{8}$.

Now we have to find the area of the triangle.

We can split the triangle into two right triangles by drawing a line from the center of the circle to the midpoint of the side of the octagon.

That's true. And we know that the hypotenuse of each right triangle is the radius of the circle.

And since the area of the circle is 1, the radius of the circle is $\sqrt{\frac{1}{\pi}}$.

The central angle of the sector that coincides with the sides of the isoceles triangle has measure $\frac{2\pi}{8}$

So the right triangle has an angle at the center of the octagon that measures $\frac{\pi}{8}$

If we draw a line from the center of the circle to one of the vertices of the octagon, we can see that the right triangle has a leg of length $\sqrt{\frac{1}{\pi}}$ and an angle of $\frac{\pi}{8}$.

We have a correction, the hypothenuse of the right triangle has length $\sqrt{\frac{1}{\pi}}$ , not a leg of the right triangle

So the right triangle's side that is adjacent to the angle measuring $\frac{\pi}{8}$ has length $(\cos \frac{\pi}{8})\sqrt{\frac{1}{\pi}}$

And the right triangle's side that is opposite to the angle measuring $\frac{\pi}{8}$ has length $(\sin \frac{\pi}{8})\sqrt{\frac{1}{\pi}}$

So the right triangle has area $\frac{1}{2}((\cos \frac{\pi}{8})\sqrt{\frac{1}{\pi}})((\sin \frac{\pi}{8})\sqrt{\frac{1}{\pi}})$

And since there are two of these right triangles, the area of the central triangle is $((\cos \frac{\pi}{8})\sqrt{\frac{1}{\pi}})((\sin \frac{\pi}{8})\sqrt{\frac{1}{\pi}})$

So the area of the region bounded by the side of the octagon and the minor arc it subtends is $\frac{1}{8} - ((\cos \frac{\pi}{8})\sqrt{\frac{1}{\pi}})((\sin \frac{\pi}{8})\sqrt{\frac{1}{\pi}})$

We can use the identity $\sin 2x = 2(\sin x)( \cos x)$ to evaluate $(\sin \frac{\pi}{8})(\cos \frac{\pi}{8})$

Yeah. This is equal to $\frac{1}{2}(\sin \frac{\pi}{4}) = \frac{1}{2} \cdot \frac{\sqrt{2}}{2} = \frac{\sqrt{2}}{4}$

Then the area of the region bounded by the side of the octagon and the minor arc it subtends is $\frac{1}{8} - \frac{\sqrt{2}}{4}(\frac{1}{\pi})$

Current Step: Right. So the area of the region bounded by the side of the octagon and the minor arc it subtends is $\frac{1}{8} - \frac{\sqrt{2}}{4}(\frac{1}{\pi})$ Math reasoning: <extra>, Consistency: <extra>
```

**4class** (`1428_4class_1`, assistant turn `inputs` content):

```text
To start, we can compute the area bounded by the side of the octagon with the minor arc that it subtends

This would be the area of the sector of the circle minus the area of the triangle formed by the center of the circle and the two endpoints of the side of the octagon.

Yeah. And since an octagon has eight sides, we can divide the circle into eight equal sectors.

And we know that the area of the circle is 1, so each sector has area $\frac{1}{8}$.

Now we have to find the area of the triangle.

We can split the triangle into two right triangles by drawing a line from the center of the circle to the midpoint of the side of the octagon.

That's true. And we know that the hypotenuse of each right triangle is the radius of the circle.

And since the area of the circle is 1, the radius of the circle is $\sqrt{\frac{1}{\pi}}$.

The central angle of the sector that coincides with the sides of the isoceles triangle has measure $\frac{2\pi}{8}$

So the right triangle has an angle at the center of the octagon that measures $\frac{\pi}{8}$

If we draw a line from the center of the circle to one of the vertices of the octagon, we can see that the right triangle has a leg of length $\sqrt{\frac{1}{\pi}}$ and an angle of $\frac{\pi}{8}$.

We have a correction, the hypothenuse of the right triangle has length $\sqrt{\frac{1}{\pi}}$ , not a leg of the right triangle

So the right triangle's side that is adjacent to the angle measuring $\frac{\pi}{8}$ has length $(\cos \frac{\pi}{8})\sqrt{\frac{1}{\pi}}$

And the right triangle's side that is opposite to the angle measuring $\frac{\pi}{8}$ has length $(\sin \frac{\pi}{8})\sqrt{\frac{1}{\pi}}$

So the right triangle has area $\frac{1}{2}((\cos \frac{\pi}{8})\sqrt{\frac{1}{\pi}})((\sin \frac{\pi}{8})\sqrt{\frac{1}{\pi}})$

And since there are two of these right triangles, the area of the central triangle is $((\cos \frac{\pi}{8})\sqrt{\frac{1}{\pi}})((\sin \frac{\pi}{8})\sqrt{\frac{1}{\pi}})$

So the area of the region bounded by the side of the octagon and the minor arc it subtends is $\frac{1}{8} - ((\cos \frac{\pi}{8})\sqrt{\frac{1}{\pi}})((\sin \frac{\pi}{8})\sqrt{\frac{1}{\pi}})$

We can use the identity $\sin 2x = 2(\sin x)( \cos x)$ to evaluate $(\sin \frac{\pi}{8})(\cos \frac{\pi}{8})$

Yeah. This is equal to $\frac{1}{2}(\sin \frac{\pi}{4}) = \frac{1}{2} \cdot \frac{\sqrt{2}}{2} = \frac{\sqrt{2}}{4}$

Then the area of the region bounded by the side of the octagon and the minor arc it subtends is $\frac{1}{8} - \frac{\sqrt{2}}{4}(\frac{1}{\pi})$

Current Step: Right. So the area of the region bounded by the side of the octagon and the minor arc it subtends is $\frac{1}{8} - \frac{\sqrt{2}}{4}(\frac{1}{\pi})$ Calculation: <extra>, Method: <extra>, Prior-step consistency: <extra>, Domain consistency: <extra>
```

### 6.2 Full System Prompts for All Four Versions

During evaluation, you **must use the exact same system prompt as the corresponding training version** (i.e., the opening sentence of the user turn); do not mix them:

**0class**:

> You are a Math Teacher. Given a question and a student's solution, evaluate whether the current step will lead to the correct final solution

**1class**:

> You are a Math Teacher. Given a question and a student's solution, evaluate whether the current step contains any error and whether it will lead to the correct final solution

**2class**:

> You are a Math Teacher. Given a question and a student's solution, evaluate the mathematical correctness, logic consistency of the current step and whether it will lead to the correct final solution

**4class**:

> You are a Math Teacher. Given a question and a student's solution, evaluate the calculation correctness, method validity, consistency with prior steps, and consistency with the problem domain of the current step and whether it will lead to the correct final solution

### 6.3 Inference Flow and Reward Computation per Version

- **0class**: Single forward pass; predict directly at the Correctness position; take the softmax probability corresponding to `<+>` at that position as the reward score for this step.
- **1/2/4class (two stages)**:
  1. First forward pass: predict at the stage-1 label positions (`<extra>`); take the argmax between `<+>` and `<->` tokens from the logits at each position.
  2. Substitute the predicted stage-1 label tokens back into the text, append `, Correctness: <extra>` at the end, and perform a second forward pass. Take the softmax probability corresponding to `<+>` at the Correctness position as the reward score for this step.

**An important detail about whether to always run the second forward pass — from the official code**: After checking the paper's Appendix C and the official evaluation code (`src/evaluation/reward_guided_search/PathFinderPRM.py`, implemented for 2-class):

- The pseudocode in Appendix C (Algorithm 1) describes "always perform two forward passes": first predict stage-1 labels, then unconditionally perform the second forward pass to predict Correctness, taking `softmax(Logits2 at Correctness mask position)` for the `<+>` probability as the reward.
- However, **the official code has an optimization not mentioned in the paper**: in `inference_single()`, if any stage-1 predicted label is `<->` (issue), it directly `return -1` (reward hardcoded to -1), **skipping the second forward pass** and not actually computing the Correctness probability. Only when all stage-1 predictions are `<+>` (no issue) does it actually perform the second forward pass and take the softmax probability as the reward.
- This optimization has **only been verified in the official 2-class implementation**. Whether 1-class and 4-class versions should adopt the same logic of "skip stage 2 and directly assign -1 if any stage-1 label is negative" has no corresponding official code — **please refer to the official evaluation code's actual behavior**. If you need to implement 1/4-class inference yourself, it is recommended to first confirm whether to replicate this optimization before proceeding, rather than assuming based on this README's description.

### 6.4 Evaluation Scope and Alignment Requirements

- The training data has **fully excluded** any questions that overlap with PRMBench, so in theory PRMBench questions should not appear in the training data.
- The four versions are trained on **exactly the same set of samples** (same questions, same steps); the only variable is label granularity. To ensure fair comparison across versions, **all four versions must be evaluated on the same fixed PRMBench subset using the same evaluation metrics** — do not pick different subsets or use different metrics for different versions.

## 7. Known Differences and Reminders

Below are differences or potential sources of confusion between the data, the paper, and the official code that we noticed during data preparation. We only list the facts and possible impacts here; how to handle them is left to the training/evaluation team to decide — no experimental-design conclusions are given here.

**a. Inconsistency between the paper's Appendix C pseudocode and the official 2-class evaluation code (reward_guided_search)**

- Observation: The pseudocode in Appendix C always performs two forward passes; but the official `src/evaluation/reward_guided_search/PathFinderPRM.py`'s `inference_single()` directly returns reward=-1 and skips the second forward pass whenever any stage-1 predicted label is `<->`, only performing the second forward pass to compute the Correctness probability when all stage-1 predictions are `<+>` (see Section 6.3 for details).
- Possible impact: Implementing based on the pseudocode vs. the official code may yield different reward distributions for the same model (the short-circuit branch directly assigns -1 rather than a real softmax probability).
- For you to decide: Which implementation to use for evaluation code — follow the official evaluation code's actual behavior, or strictly follow the paper. Please decide for yourself.

**b. Relationship between the "skip second forward pass" rule and the number of labels**

- Observation: Whether this short-circuit rule triggers depends on whether any stage-1 predicted label is `<->`. The more stage-1 labels there are (e.g., 4 labels in 4-class vs. 1 label in 1-class), the higher the theoretical probability of at least one `<->`, and thus the higher the probability of short-circuiting (skipping the second forward pass, directly assigning reward=-1). The official code currently only implements this rule for 2-class; there is no corresponding official code for 1-class or 4-class.
- Possible impact: If 1/2/4-class evaluations handle this rule inconsistently (e.g., 2-class uses the short-circuit but 1/4-class don't, or vice versa), the score differences between versions may be confounded by this factor rather than purely reflecting label granularity differences.
- For you to decide: This section only reminds that this confounding factor may exist; no conclusion is drawn on whether 1/4-class should replicate this rule.

**c. The actual PRMBench evaluation code in the official repository is not the same logic as reward_guided_search**

- [Verified facts]: `src/evaluation/prm_bench_eval.sh` calls the `mr_eval` module (`src/evaluation/PRMBench/mr_eval/`), whose model registry (`mr_eval/models/__init__.py`) registers the discriminative PRM under the name `disc_PRM`, pointing to the `MyDiscriminativePRM` class in `mr_eval/models/disc_PRM.py` — **not** `reward_guided_search/PathFinderPRM.py`. The two codebases have different reward computation logic:
  - `disc_PRM.py` uses a **single forward pass**: sets all label positions to be predicted for that version to `<extra>` in the same assistant content, runs one forward pass, and directly reads the softmax probability of `<+>` at each `<extra>` position — **no two-stage, no separate Correctness prediction**; the step score is the average of the `<+>` probabilities across all `<extra>` positions.
  - The label positions in `disc_PRM.py` are currently **hardcoded** as `Math reasoning` and `Consistency` (i.e., only for 2-class); there is no corresponding implementation for 0/1/4-class.
  - The system prompt used by `disc_PRM.py` is also a hardcoded single sentence, different from `build_dataset.py`/`build_dataset_ablation.py`'s `SYSTEM_PROMPT` (missing the "...and whether it will lead to the correct final solution" half), and also different from our four-version system prompts (see Section 6.2).
  - `disc_PRM.py` uses `"Current step: "` (lowercase step) as the step text prefix, while our training data uses `"Current Step: "` (uppercase Step; see Section 6.1).
  - The configuration file `disc_prm_eval.yaml` referenced by `src/evaluation/prm_bench_eval.sh` **was not found** in the cloned official repository (the repository only contains example configs for other models), so the specific settings (e.g., `validity_threshold` parameters) are **unverified**.
- Possible impact: If you directly reuse `disc_PRM.py`'s existing logic for evaluation, the score definition (average of probabilities across multiple label positions) and the "two-stage + Correctness reward" described in Section 6.3 are two different things and cannot be directly compared; moreover, the existing code only supports 2-class, and 0/1/4-class need to be extended. If the system prompt and `Current Step` capitalization are not aligned with the training format, this may introduce additional distribution shift.
- For you to decide: The evaluation team needs to decide whether to reuse the `disc_PRM.py` PRMBench evaluation approach (which requires extending to 0/1/4-class and deciding whether to align the prompt/capitalization) or to adopt the two-stage + Correctness reward approach from Section 6.3. The two are not comparable — do not mix them.

**d. The 0-class system prompt differs from the official ablation script**

- Observation: The official `build_dataset_ablation.py` (single-stage, only outputs Correctness) reuses the exact same complete system prompt as `build_dataset.py` (2-class), which includes the "mathematical correctness, logic consistency" error category description, without any trimming for the single-stage output. Our 0-class prompt removes the error category description (see Section 6.2).
- Possible impact: If comparing the official 0-class (ablation) model's evaluation results with our 0-class model, the system prompt text used during training is itself different, which could be a cause of differences.
- For you to decide: This section only states the difference factually; no conclusion is drawn on which prompt is more reasonable.

**e. Statistics on "# Answer" in step text**

- [Verified facts]: In our four-version dataset, there are **153** records whose current step (curr_step) text contains "# Answer" (shared across all four versions since they use the same set of curr_steps, accounting for **6.6%** of 2,330 distinct records). In the local PRMBench data (`src/evaluation/reward_guided_search/eval_data/PRMBench_Preview/prmbench_preview.jsonl`), there are **737** steps containing "# Answer" (accounting for **0.9%** of all 83,456 steps), distributed across **737** questions (accounting for **11.9%** of all 6,216 questions, i.e., these questions have at least one step with "# Answer"). The two sides use different counting units (we count by record/curr_step; PRMBench here counts by step and by question separately). No difference was found in the presentation format of "# Answer" between the two sides — it is a phenomenon that already exists in the original PRM800K step segmentation.
- Possible impact: If the training or evaluation code has special handling for steps containing "# Answer" (e.g., separately identifying them as "final answer steps" and skipping scoring), both sides' data contain such steps, so the handling must be consistent.
- For you to decide: Whether special handling for steps containing "# Answer" is needed is left to the training/evaluation team to decide; no conclusion is given here.

**f. Label semantics of suboptimal steps need to be mapped by the evaluation team**

- Observation: In the training data, suboptimal steps (`human_score=0`) have Correctness labeled as `<->`, but all error labels (Error/Math reasoning/Consistency/Calculation/Method/Prior-step consistency/Domain consistency) are labeled as `<+>` (because these steps did not go through the error-type annotation process; see Section 8 for details).
- Possible impact: If PRMBench or other evaluation benchmarks have a label definition for "suboptimal" that is independent of "completely erroneous," this treatment of "suboptimal = Correctness wrong, but all error dimensions treated as no issue" may not exactly correspond to the evaluation benchmark's label semantics.
- For you to decide: How suboptimal steps should be mapped/interpreted during evaluation is left to the evaluation team to confirm; no conclusion is given here.

## 8. Sample Composition

Error side: **1,165** records; correct side: **1,165** records (1:1). Within the correct side, suboptimal steps (`human_score=0`, Correctness = `<->` but error labels all treated as `<+>`) account for **156** records, i.e., **13.4%** of the correct side.

Number of records per error label on the error side (a record matching multiple labels is counted in all matching categories, so the totals below exceed 1,165):

| Label | Record count |
|---|---:|
| calc (calculation error) | 503 |
| method (method/formula error) | 493 |
| prior (contradiction with prior steps) | 75 |
| domain (contradiction with problem/math domain) | 498 |

**Reminder**: The prior category is notably underrepresented (75 records, only about one-sixth to one-seventh of the other three categories). When evaluating the 4-class model's classification performance, it is recommended to look at per-class metrics (e.g., precision/recall/F1 per class) rather than a single aggregated overall accuracy — the overall accuracy will be dominated by the majority classes (calc/method) and may mask the performance on the prior class.

## 9. Notes

- Error labels were auto-annotated by an LLM and filtered for consistency (samples contradicting human annotations were removed), but labeling noise still exists, especially for the rarer prior class. Please do not assume the labels are 100% accurate.
- The training data has excluded questions that overlap with PRMBench (see the evaluation section above).
- Character length distribution (assistant content) per version:

| Version | Median | P95 | Max |
|---|---:|---:|---:|
| 0class | 734.5 | 1829 | 7236 |
| 1class | 738.0 | 1837 | 7248 |
| 2class | 765.0 | 1864 | 7275 |
| 4class | 811.0 | 1910 | 7321 |

The above are **character counts**, not token counts; different tokenizers will yield different token counts. Please re-compute using the tokenizer you use for training/evaluation — do not directly use character counts as token counts.

## 10. Reading Example

Using only the Python standard library `json`, read one version's JSONL file and split into training/validation sets by `val_question_ids.json` (the following code has been actually run; the output is real, not hand-written):

```python
import json

with open("val_question_ids.json", encoding="utf-8") as f:
    val = json.load(f)
val_qids = set(val["val_question_ids"])

train, val_rows = [], []
with open("prm_2class.jsonl", encoding="utf-8") as f:
    for line in f:
        row = json.loads(line)
        (val_rows if row["question_id"] in val_qids else train).append(row)

print(f"train rows: {len(train)}, val rows: {len(val_rows)}")
print(f"distinct val question_ids used: {len(val_qids)}")
print("first train row id:", train[0]["id"])
print("first train row labels (assistant content, truncated):",
      train[0]["labels"][1]["content"][-120:])
```

Actual run output:

```
train rows: 4432, val rows: 228
distinct val question_ids used: 93
first train row id: 10220_2class_1
first train row labels (assistant content, truncated): -3) = 2 \cdot 4 + 2 \cdot -6 + 9 - 2 \cdot 2 + 2 \cdot -3 + 4 = -8$.

# Answer

-8 Math reasoning: <->, Consistency: <+>
```
