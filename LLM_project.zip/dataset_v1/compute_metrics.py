# -*- coding: utf-8 -*-
"""Aggregate results under test_results/ and generate a paper-style comparison table.

Auto-detects the label dimensions of each result file (see test_local_lora.py header for protocol):
  0class : correctness (1=<+> correct)
  1class : error (1=<-> erroneous)
  2class : math, consistency (1=<->)
  4class : calculation, method, prior_step, domain (1=<->)
           and auto-aggregates to 2class formulation (math=calc OR method,
           consistency=prior OR domain) for fair cross-granularity comparison.

Per file outputs:
  * Per-dimension accuracy / P / R / F1 / support, macro-F1;
  * Step-level binary (erroneous <-> vs correct <+>) P/R/F1 and 2way accuracy;
  * Exact-match rate;
  * Binary accuracy on the common record_id subset across files (stricter fair comparison).

Usage:
  python compute_metrics.py                       # default reads test_results/
  python compute_metrics.py --result_dir test_results
  python compute_metrics.py --files a.jsonl b.jsonl
Output:
  <result_dir>/comparison_table.md   paper-style Markdown table
  <result_dir>/comparison_metrics.json  all metrics (machine-readable)
"""
import argparse
import glob
import json
import os
import re

# 4class -> 2class aggregation rule
AGGREGATE_2CLASS = {
    "math": ["calculation", "method"],
    "consistency": ["prior_step", "domain"],
}
# Dimension display order
DIM_ORDER = [
    "correctness", "error", "math", "consistency",
    "calculation", "method", "prior_step", "domain",
]


def load_rows(path):
    """Read result jsonl, discard summary rows and parse-failure rows.

    Returns (list of normal record rows, summary row or None).
    """
    rows = []
    summary = None
    for line in open(path, encoding="utf-8"):
        r = json.loads(line)
        if r.get("type") == "summary":
            summary = r
            continue
        if not r.get("ground_truth") or not r.get("predicted"):
            continue
        rows.append(r)
    return rows, summary


# Known experimental conditions for old files without summary (e.g. online platform API test results)
KNOWN_PROVENANCE = {
    "4class_test_results.jsonl": {
        "base_model": "qwen3-32b (online full-FT)",
        "training_method": "online full-FT",
    },
}


def prf(tp, fp, fn):
    p = tp / (tp + fp) if tp + fp else 0.0
    r = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2 * p * r / (p + r) if p + r else 0.0
    return p, r, f1


def dim_prf(rows, dim, gt_getter):
    tp = fp = fn = correct = total = 0
    for r in rows:
        d = gt_getter(r)
        if dim not in d:
            continue
        g = d[dim]
        p = getter_pred(r)[dim]
        total += 1
        correct += int(g == p)
        tp += int(g == 1 and p == 1)
        fp += int(g == 0 and p == 1)
        fn += int(g == 1 and p == 0)
    p, r, f1 = prf(tp, fp, fn)
    return {
        "accuracy": correct / total if total else 0.0,
        "precision": p, "recall": r, "f1": f1, "support": total,
    }


def getter_pred(r):
    return r["predicted"]


def binary_error_flags(r):
    """Return (whether ground truth is erroneous, whether prediction is erroneous).

    correctness dimension: 1=correct; error-class dimensions: 1=erroneous.
    """
    gt, pd = r["ground_truth"], r["predicted"]
    if "correctness" in gt:
        return (1 - gt["correctness"]), (1 - pd["correctness"])
    g_err = int(any(v == 1 for k, v in gt.items() if k != "correctness"))
    p_err = int(any(v == 1 for k, v in pd.items() if k != "correctness"))
    return g_err, p_err


def eval_file(path):
    rows, summary = load_rows(path)
    # Compatible with both 0class_results.jsonl and 4class_test_results.jsonl naming
    name = re.sub(r"_(test_)?results$", "",
                  os.path.basename(path)[:-len(".jsonl")]
                  if path.endswith(".jsonl") else os.path.basename(path))
    if not rows:
        return None

    # Experimental conditions: prefer summary fields in result file; fall back to known old-file table
    fname = os.path.basename(path)
    fallback = KNOWN_PROVENANCE.get(fname, {})
    provenance = {
        "base_model": (summary or {}).get("base_model")
                      or fallback.get("base_model", "unknown"),
        "training_method": (summary or {}).get("training_method")
                      or fallback.get("training_method", "unknown"),
    }

    dims = sorted(
        {d for r in rows for d in r["ground_truth"]},
        key=lambda d: DIM_ORDER.index(d) if d in DIM_ORDER else 99,
    )
    per_dim = {d: dim_prf(rows, d, lambda r: r["ground_truth"]) for d in dims}
    macro_f1 = sum(v["f1"] for v in per_dim.values()) / len(per_dim)

    # Step-level binary classification
    tp = fp = fn = tn = 0
    for r in rows:
        g, p = binary_error_flags(r)
        tp += int(g == 1 and p == 1); fp += int(g == 0 and p == 1)
        fn += int(g == 1 and p == 0); tn += int(g == 0 and p == 0)
    bp, br, bf1 = prf(tp, fp, fn)
    acc2 = (tp + tn) / len(rows)

    em = sum(1 for r in rows if r.get("exact_match")) / len(rows)

    # Actual ratio of steps predicted as "erroneous"
    actual_error_rate = sum(
        binary_error_flags(r)[1] == 1 for r in rows
    ) / len(rows) if rows else 0.0

    out = {
        "file": os.path.basename(path),
        "model": name,
        "provenance": provenance,
        "n_records": len(rows),
        "dims": dims,
        "per_dim": per_dim,
        "macro_f1": macro_f1,
        "binary": {
            "precision": bp, "recall": br, "f1": bf1,
            "accuracy_2way": acc2,
            "tp": tp, "fp": fp, "fn": fn, "tn": tn,
        },
        "exact_match_rate": em,
        "actual_error_rate": actual_error_rate,
        "record_ids": {r.get("record_id") for r in rows},
        "rows": rows,
    }

    # 4class aggregated to 2class formulation
    if all(d in dims for d in ("calculation", "method",
                               "prior_step", "domain")):
        agg = {}
        for new_d, members in AGGREGATE_2CLASS.items():
            tp = fp = fn = 0
            for r in rows:
                g = int(any(r["ground_truth"][m] == 1 for m in members))
                p = int(any(r["predicted"][m] == 1 for m in members))
                tp += int(g == 1 and p == 1)
                fp += int(g == 0 and p == 1)
                fn += int(g == 1 and p == 0)
            p, rr, f1 = prf(tp, fp, fn)
            support = sum(
                int(any(r["ground_truth"][m] == 1 for m in members))
                for r in rows
            )
            agg[new_d] = {"precision": p, "recall": rr, "f1": f1,
                          "support_error": support}
        out["aggregated_2class"] = agg
        out["aggregated_2class_macro_f1"] = (
            agg["math"]["f1"] + agg["consistency"]["f1"]
        ) / 2
    return out


def build_table(reports):
    """Generate Markdown comparison table."""
    all_dims = []
    for rep in reports:
        for d in rep["dims"]:
            if d not in all_dims:
                all_dims.append(d)
    all_dims.sort(key=lambda d: DIM_ORDER.index(d) if d in DIM_ORDER else 99)

    bases = {r["provenance"]["base_model"] for r in reports}

    # Compute naive baseline (predict every step as erroneous)
    # and actual predicted-error ratio for each model
    if reports:
        # Naive baseline: predict all steps as erroneous
        # F1 = 2 * P * R / (P + R), where P = error_rate, R = 1.0
        # Use the overall error rate across all records as baseline P
        total_steps = sum(r["n_records"] for r in reports)
        total_errors = sum(
            sum(1 for row in r["rows"]
                if binary_error_flags(row)[0] == 1)
            for r in reports
        )
        baseline_error_rate = total_errors / total_steps if total_steps else 0.5
        baseline_p = baseline_error_rate
        baseline_r = 1.0
        baseline_f1 = (2 * baseline_p * baseline_r
                       / (baseline_p + baseline_r)
                       if (baseline_p + baseline_r) else 0.0)

    lines = [
        "# PRM Comparative Experiment Results (Error-Label Granularity Comparison)",
        "",
        "> All models: same validation split (val_question_ids.json), seed=42, same training hyper-parameters.",
        "> For error-class dimension F1, the positive class is \"erroneous (<->)\"; for correctness dimension F1, the positive class is \"correct (<+>)\".",
    ]
    if len(bases) > 1:
        lines += [
            "",
            "> WARNING: Models have different base/training methods (see table below). "
            "Label granularity is not the only variable; absolute cross-model comparisons are for reference only. "
            "Rigorous controlled ablation requires retraining all versions on the same base model.",
        ]
    lines += [
        "",
        "## 1. Main Table: Native Granularity per Version",
        "",
    ]
    header = (["Model", "Base / Training Method", "n"]
               + [f"{d} F1" for d in all_dims]
               + ["macro-F1", "2way acc", "Error Detection F1",
                  "exact-match", "Error Ratio"])
    lines.append("| " + " | ".join(header) + " |")
    lines.append("|" + "---|" * len(header))
    for rep in reports:
        prov = rep["provenance"]
        prov_txt = f"{prov['base_model']} / {prov['training_method']}"
        cells = [rep["model"], prov_txt, str(rep["n_records"])]
        for d in all_dims:
            cells.append(f"{rep['per_dim'][d]['f1']:.3f}"
                         if d in rep["per_dim"] else "—")
        cells += [
            f"{rep['macro_f1']:.3f}",
            f"{rep['binary']['accuracy_2way']:.3f}",
            f"{rep['binary']['f1']:.3f}",
            f"{rep['exact_match_rate']:.3f}",
            f"{rep['actual_error_rate']:.1%}",
        ]
        lines.append("| " + " | ".join(cells) + " |")

    # Naive baseline row
    if reports:
        lines.append(
            f"| all-negative baseline | — | {total_steps} | "
            + " | ".join("—" for _ in all_dims) + " | "
            f"— | — | {baseline_f1:.3f} | — | {baseline_error_rate:.1%} |"
        )
        lines.append(
            f"\n> all-negative baseline: predict every step as erroneous "
            f"(error ratio 100%). With actual error rate "
            f"{baseline_error_rate:.1%}, F1={baseline_f1:.3f}. "
            f"Models with Error Ratio close to 100% are degenerate."
        )

    # Per-dimension P/R/support
    lines += ["", "## 2. Per-Dimension Details (P / R / F1 / support)", ""]
    for rep in reports:
        lines.append(f"### {rep['model']} ({rep['n_records']} samples)")
        lines.append("")
        lines.append("| Dimension | Precision | Recall | F1 | Acc | support |")
        lines.append("|---|---|---|---|---|---|")
        for d, m in rep["per_dim"].items():
            lines.append(
                f"| {d} | {m['precision']:.3f} | {m['recall']:.3f} "
                f"| {m['f1']:.3f} | {m['accuracy']:.3f} | {m['support']} |"
            )
        lines.append("")

    # 4class aggregation
    agg_reps = [r for r in reports if "aggregated_2class" in r]
    if agg_reps:
        lines += ["## 3. 4class Aggregated to 2class Formulation", "",
                  "Aggregation rule: math = calculation OR method; "
                  "consistency = prior_step OR domain.",
                  "",
                  "| Model | math F1 | consistency F1 | macro-F1 |",
                  "|---|---|---|---|"]
        for rep in agg_reps:
            a = rep["aggregated_2class"]
            lines.append(
                f"| {rep['model']} | {a['math']['f1']:.3f} "
                f"| {a['consistency']['f1']:.3f} "
                f"| {rep['aggregated_2class_macro_f1']:.3f} |"
            )
        lines.append("")

    # Fair comparison on common record_id subset
    if len(reports) >= 2:
        common = set.intersection(*[r["record_ids"] for r in reports])
        common.discard(None)
        if common:
            lines += [
                "## 4. Step-Level Binary Accuracy on Common Sample Subset",
                "",
                f"Intersection of record_ids across all result files: **{len(common)}** samples.",
                "",
                "| Model | 2way acc | Error Detection P | Error Detection R | Error Detection F1 |",
                "|---|---|---|---|---|",
            ]
            for rep in reports:
                sub = [r for r in rep["rows"] if r.get("record_id") in common]
                tp = fp = fn = tn = 0
                for r in sub:
                    g, p = binary_error_flags(r)
                    tp += int(g == 1 and p == 1); fp += int(g == 0 and p == 1)
                    fn += int(g == 1 and p == 0); tn += int(g == 0 and p == 0)
                p, rr, f1 = prf(tp, fp, fn)
                lines.append(
                    f"| {rep['model']} | {(tp+tn)/len(sub):.3f} "
                    f"| {p:.3f} | {rr:.3f} | {f1:.3f} |"
                )
            lines.append("")
    return "\n".join(lines)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--result_dir", default="test results")
    ap.add_argument("--files", nargs="*", default=None,
                    help="Explicitly specify result files; if not given, scan result_dir/*.jsonl")
    args = ap.parse_args()

    if args.files:
        paths = args.files
    else:
        paths = sorted(glob.glob(os.path.join(args.result_dir, "*.jsonl")))
    paths = [p for p in paths if os.path.basename(p) !=
             "comparison_metrics.json"]

    reports = []
    for p in paths:
        rep = eval_file(p)
        if rep:
            reports.append(rep)
            print(f"[load] {p}: {rep['n_records']} records, "
                  f"dims={rep['dims']}, 2way acc="
                  f"{rep['binary']['accuracy_2way']:.3f}")
    if not reports:
        raise SystemExit("No usable result files found")

    # Sort: 0/1/2/4class first
    order = {"0class": 0, "1class": 1, "2class": 2, "4class": 3}
    reports.sort(key=lambda r: order.get(r["model"], 9))

    table = build_table(reports)
    md_path = os.path.join(args.result_dir, "comparison_table.md")
    with open(md_path, "w", encoding="utf-8") as f:
        f.write(table)

    dump = []
    for rep in reports:
        d = {k: v for k, v in rep.items() if k != "rows"}
        d["record_ids"] = sorted(x for x in d["record_ids"] if x is not None)
        dump.append(d)
    json_path = os.path.join(args.result_dir, "comparison_metrics.json")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(dump, f, ensure_ascii=False, indent=2)

    print(f"\n{table}\n")
    print(f"Comparison table saved: {md_path}")
    print(f"Metrics JSON     : {json_path}")


if __name__ == "__main__":
    main()
