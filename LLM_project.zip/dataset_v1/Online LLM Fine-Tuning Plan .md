# Online Qwen-Math Large Model Fine-Tuning Plan (Based on 4-Class Error Taxonomy)
# For English version, see online model fine-tuning.md
 
## 1. Design Philosophy

For online large model APIs / cloud fine-tuning (e.g., Qwen2.5-Math-7B-Instruct / 72B-Instruct), this plan abandons the traditional two-step masked forward pass in favor of a Chain-of-Thought (CoT) + structured JSON output single-pass mode.

### Core Advantages
1. Eliminates Mask Token dependency: No need to directly read model logits or modify the tokenizer; fully compatible with cloud APIs / DashScope fine-tuning platform.
2. Maximizes reasoning capability: Lets Qwen-Math output 1-2 sentences of analysis logic before generating classification labels, using CoT to significantly reduce confusion between Calc (calculation error) and Method (method error).
3. High extensibility: JSON structure facilitates downstream parsing and PRM path scoring.

---

## 2. Four Error Type Definitions

The model must evaluate the following 4 dimensions for each input reasoning step (outputting boolean true / false):

1. calc_error (Calculation Error): Pure numerical arithmetic, algebraic simplification, equation solving, or symbolic transformation errors.
2. method_error (Method Error): Use of incorrect formulas, theorems, or illegal mathematical operations, or a fundamental flaw in the overall derivation logic.
3. prior_inconsistency (Prior-Step Inconsistency): The current step contradicts previously derived steps or intermediate conclusions.
4. domain_inconsistency (Domain/Condition Inconsistency): The current step contradicts the original problem statement, given conditions, or axioms/definitions of the mathematical domain (e.g., division by zero, negative under an even-index root).

---

## 3. Dataset Construction and Format Conversion

First, use a strong model (e.g., DeepSeek-R1 API) to annotate the PRM800K dataset with 4-dimensional labels and perform consistency filtering, then convert to JSONL format (train.jsonl) suitable for Qwen-Math fine-tuning:

```json
{
  "messages": [
    {
      "role": "system",
      "content": "You are a strict math reasoning step evaluator. You need to check each of the following 4 error types for the student's current step:\n1. calc_error: arithmetic or algebraic calculation error\n2. method_error: formula or derivation logic error\n3. prior_inconsistency: contradicts prior derivation results\n4. domain_inconsistency: contradicts problem conditions or mathematical definitions"
    },
    {
      "role": "user",
      "content": "Question: Solve the equation x^2 - 5x + 6 = 0\nPrevious steps:\nStep 1: Factor to get (x - 2)(x - 3) = 0\nCurrent step:\nStep 2: So x = -2 or x = -3"
    },
    {
      "role": "assistant",
      "content": "Analysis: Step 1 yields x=2 and x=3. Step 2 incorrectly flips the signs, which is a pure calculation/symbolic simplification error and also contradicts prior logic.\n```json\n{\n  \"calc_error\": true,\n  \"method_error\": false,\n  \"prior_inconsistency\": true,\n  \"domain_inconsistency\": false\n}\n```"
    }
  ]
}
```

---

## 4. Fine-Tuning Practical Steps

### Path A: Online Fine-Tuning via Alibaba Cloud DashScope
1. Data preparation: Upload the filtered train.jsonl (~1,500–3,000 samples) to the Alibaba Cloud DashScope platform.
2. Model selection: Select Qwen2.5-Math-7B-Instruct.
3. Hyperparameter settings:
   - Training method: LoRA
   - Epochs: 3
   - Learning Rate: 2e-4
   - Batch Size: 8 or 16
4. Model deployment: After training, a dedicated service endpoint is generated directly.

### Path B: Fine-Tuning via MS-Swift Framework on Cloud GPU Servers (A100 / L4)
If you choose self-managed deployment, you can use Alibaba's open-source Swift framework for training:

```bash
# Install Swift
pip install ms-swift[llm]

# Launch fine-tuning
swift sft \
    --model_type qwen2_5-math-7b-instruct \
    --dataset train.jsonl \
    --val_dataset val.jsonl \
    --num_train_epochs 3 \
    --per_device_train_batch_size 4 \
    --learning_rate 2e-4 \
    --lora_rank 16 \
    --lora_alpha 32 \
    --output_dir ./output_qwen_math_4prm
```

---

## 5. Inference and Integration Code

Below is the complete Python code for calling the fine-tuned online model via the OpenAI API standard interface, with automatic parsing of the 4 error types and path reward score computation:

```python
import json
import re
from openai import OpenAI

# 1. Initialize client
client = OpenAI(
    api_key="YOUR_API_KEY", 
    base_url="https://dashscope.aliyuncs.com/compatible-mode/v1"
)

SYSTEM_PROMPT = """You are a strict math reasoning step evaluator. You need to check each of the following 4 error types for the student's current step:
1. calc_error: arithmetic or algebraic calculation error
2. method_error: formula or derivation logic error
3. prior_inconsistency: contradicts prior derivation results
4. domain_inconsistency: contradicts problem conditions or mathematical definitions"""

def predict_4_errors(question, previous_steps, current_step, model_name="ft-qwen-math-4prm"):
    user_content = f"Question: {question}\nPrevious steps:\n{previous_steps}\nCurrent step:\n{current_step}"
    
    response = client.chat.completions.create(
        model=model_name,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_content}
        ],
        temperature=0.1,
        max_tokens=256
    )
    
    output_text = response.choices[0].message.content
    
    # 2. Parse JSON labels
    try:
        json_match = re.search(r'```json\s*(\{.*?\})\s*```', output_text, re.DOTALL)
        if json_match:
            error_dict = json.loads(json_match.group(1))
        else:
            error_dict = json.loads(output_text)
    except Exception as e:
        # Fallback reset on parse failure
        error_dict = {
            "calc_error": False, 
            "method_error": False, 
            "prior_inconsistency": False, 
            "domain_inconsistency": False
        }
        
    # 3. Compute path reward score
    has_error = any(error_dict.values())
    reward_score = 0.0 if has_error else 1.0
    
    return {
        "analysis": output_text,
        "errors": error_dict,
        "reward_score": reward_score
    }

# Run example
if __name__ == "__main__":
    res = predict_4_errors(
        question="Find the derivative of y = x^2 at x=3",
        previous_steps="Step 1: y' = 2x",
        current_step="Step 2: When x=3, y' = 5"
    )
    print("Analysis and results:\n", res["analysis"])
    print("Error prediction vector:", res["errors"])
    print("Path reward score:", res["reward_score"])
```
