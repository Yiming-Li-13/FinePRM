# PRM Comparative Experiment Results (Error-Label Granularity Comparison)

> All models: same validation split (val_question_ids.json), seed=42, same training hyper-parameters.
> For error-class dimension F1, the positive class is "erroneous (<->)"; for correctness dimension F1, the positive class is "correct (<+>)".

## 1. Main Table: Native Granularity per Version

| Model | Base / Training Method | n | correctness F1 | error F1 | math F1 | consistency F1 | calculation F1 | method F1 | prior_step F1 | domain F1 | macro-F1 | 2way acc | Error Detection F1 | exact-match | Error Ratio |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0class | Qwen/Qwen2.5-Math-1.5B-Instruct / LoRA | 80 | 0.000 | — | — | — | — | — | — | — | 0.000 | 0.550 | 0.710 | 0.550 | 100.0% |
| 1class | Qwen/Qwen2.5-Math-1.5B-Instruct / LoRA | 63 | — | 0.341 | — | — | — | — | — | — | 0.341 | 0.571 | 0.341 | 0.571 | 15.9% |
| 2class | Qwen/Qwen2.5-Math-1.5B-Instruct / LoRA | 61 | — | — | 0.000 | 0.329 | — | — | — | — | 0.164 | 0.492 | 0.659 | 0.066 | 100.0% |
| 4class | Qwen/Qwen2.5-Math-1.5B-Instruct / LoRA | 57 | — | — | — | — | 0.000 | 0.222 | 0.000 | 0.353 | 0.144 | 0.526 | 0.471 | 0.351 | 42.1% |
| all-negative baseline | — | 261 | — | — | — | — | — | — | — | — | — | — | 0.672 | — | 50.6% |

> all-negative baseline: predict every step as erroneous (error ratio 100%). With actual error rate 50.6%, F1=0.672. Models with Error Ratio close to 100% are degenerate.

## 2. Per-Dimension Details (P / R / F1 / support)

### 0class (80 samples)

| Dimension | Precision | Recall | F1 | Acc | support |
|---|---|---|---|---|---|
| correctness | 0.000 | 0.000 | 0.000 | 0.550 | 80 |

### 1class (63 samples)

| Dimension | Precision | Recall | F1 | Acc | support |
|---|---|---|---|---|---|
| error | 0.700 | 0.226 | 0.341 | 0.571 | 63 |

### 2class (61 samples)

| Dimension | Precision | Recall | F1 | Acc | support |
|---|---|---|---|---|---|
| math | 0.000 | 0.000 | 0.000 | 0.574 | 61 |
| consistency | 0.197 | 1.000 | 0.329 | 0.197 | 61 |

### 4class (57 samples)

| Dimension | Precision | Recall | F1 | Acc | support |
|---|---|---|---|---|---|
| calculation | 0.000 | 0.000 | 0.000 | 0.807 | 57 |
| method | 1.000 | 0.125 | 0.222 | 0.754 | 57 |
| prior_step | 0.000 | 0.000 | 0.000 | 0.895 | 57 |
| domain | 0.250 | 0.600 | 0.353 | 0.614 | 57 |

## 3. 4class Aggregated to 2class Formulation

Aggregation rule: math = calculation OR method; consistency = prior_step OR domain.

| Model | math F1 | consistency F1 | macro-F1 |
|---|---|---|---|
| 4class | 0.154 | 0.343 | 0.248 |

## 4. Step-Level Binary Accuracy on Common Sample Subset

Intersection of record_ids across all result files: **57** samples.

| Model | 2way acc | Error Detection P | Error Detection R | Error Detection F1 |
|---|---|---|---|---|
| 0class | 0.526 | 0.526 | 1.000 | 0.690 |
| 1class | 0.596 | 0.700 | 0.259 | 0.378 |
| 2class | 0.474 | 0.474 | 1.000 | 0.643 |
| 4class | 0.526 | 0.500 | 0.444 | 0.471 |
