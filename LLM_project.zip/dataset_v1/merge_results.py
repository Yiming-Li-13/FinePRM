# -*- coding: utf-8 -*-
"""Merge the 0/1/2/4class test result files into a per-sample comparison table.

Input: result jsonl files produced by test_local_lora.py / test_finetuned_qwen.py
       (each record contains record_id / ground_truth / predicted /
       per_dim_correct / exact_match / p_plus; summary rows are auto-skipped).
Alignment: outer join on the stable primary key record_id (does not rely on row order);
           by default keeps the union of all files; use --inner for intersection.

Table structure (columns organized by "version blocks" for horizontal comparison):
  Metadata          : question_id, record_id, side
  Unified ground truth (derived from the finest-grained file, priority 4class>2class>1class>0class):
                      gt_correctness(1=<+> correct), gt_error(1=<-> erroneous),
                      gt_math, gt_consistency,
                      gt_calculation, gt_method, gt_prior_step, gt_domain
  Per version block : that version's native dimension predictions, 2way correct(1/0),
                      exact_match(1/0), p_plus (average confidence), has result

Output:
  merged_results.csv                 always generated (UTF-8-BOM, Excel-compatible)
  merged_results.xlsx                generated if openpyxl is installed; green=correct, red=incorrect
Usage:
  python merge_results.py
  python merge_results.py --result_dir "test results" --inner
  python merge_results.py --files a.jsonl b.jsonl --output merged
"""
import argparse
import csv
import glob
import json
import os

VERSIONS = ["0class", "1class", "2class", "4class"]
# Native error dimensions per version (1=<-> erroneous)
VERSION_DIMS = {
    "0class": ["correctness"],
    "1class": ["error"],
    "2class": ["math", "consistency"],
    "4class": ["calculation", "method", "prior_step", "domain"],
}
GT_COLUMNS = [
    "gt_calculation", "gt_method", "gt_prior_step", "gt_domain",
    "gt_math", "gt_consistency", "gt_error", "gt_correctness",
]


def load_by_record(path):
    """Read result file, return {record_id: row} (summary rows and rows without record_id are skipped)."""
    out = {}
    for line in open(path, encoding="utf-8"):
        r = json.loads(line)
        if r.get("type") == "summary" or r.get("record_id") is None:
            continue
        out[r["record_id"]] = r
    return out


def name_to_version(fname):
    """Identify version from filename; compatible with 0class_results / 4class_test_results etc."""
    base = os.path.basename(fname)
    for v in VERSIONS:
        if v in base:
            return v
    return None


def unified_gt(row):
    """Derive unified ground truth dict from a result record (all 0/1).

    correctness: 1=correct(<+>); error-class dimensions: 1=erroneous(<->).
    """
    gt = row["ground_truth"]
    u = {}
    if "correctness" in gt:
        u["correctness"] = int(gt["correctness"])
        u["error"] = 1 - int(gt["correctness"])
    else:
        err = int(any(v == 1 for k, v in gt.items() if k != "correctness"))
        u["error"] = err
        u["correctness"] = 1 - err
    if "math" in gt:
        u["math"] = int(gt["math"])
    if "consistency" in gt:
        u["consistency"] = int(gt["consistency"])
    if all(k in gt for k in ("calculation", "method",
                             "prior_step", "domain")):
        u["calculation"] = int(gt["calculation"])
        u["method"] = int(gt["method"])
        u["prior_step"] = int(gt["prior_step"])
        u["domain"] = int(gt["domain"])
        # Fine-grained can derive coarse-grained (OR aggregation)
        u["math"] = int(u["calculation"] or u["method"])
        u["consistency"] = int(u["prior_step"] or u["domain"])
    return u


def merge_gt(existing, new):
    """Merge two unified ground truths: finer columns in new supplement existing (does not overwrite existing non-empty)."""
    for k, v in new.items():
        existing[k] = v  # Version iteration order ensures 4class can overwrite coarse-grained derived values when processed last
    return existing


def pred_error_flag(row):
    """Unified "is erroneous" prediction and 2way correctness for this model on this record.

    Returns None if parse failed (predicted=None); caller leaves it blank.
    """
    pd = row.get("predicted")
    if not pd:
        return None
    if "correctness" in pd:
        p_err = 1 - int(pd["correctness"])
    else:
        p_err = int(any(v == 1 for k, v in pd.items() if k != "correctness"))
    return p_err


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--result_dir", default="test results")
    ap.add_argument("--files", nargs="*", default=None)
    ap.add_argument("--output", default="merged_results",
                    help="Output file name (without extension); defaults to result_dir")
    ap.add_argument("--inner", action="store_true",
                    help="Only keep record_ids present in all files (default: union)")
    args = ap.parse_args()

    if args.files:
        paths = args.files
    else:
        paths = sorted(glob.glob(os.path.join(args.result_dir, "*.jsonl")))
    paths = [p for p in paths if os.path.basename(p) not in
             ("comparison_metrics.json",)]

    # version -> {record_id: row}
    by_version = {}
    meta = {}  # record_id -> {question_id, side}
    for p in paths:
        v = name_to_version(p)
        if v is None:
            print(f"[skip] Could not identify version from filename: {p}")
            continue
        recs = load_by_record(p)
        by_version[v] = recs
        print(f"[load] {v}: {os.path.basename(p)} -> {len(recs)} records")
        for rid, r in recs.items():
            meta.setdefault(rid, {
                "question_id": r.get("question_id"),
                "side": r.get("side"),
            })

    if not by_version:
        raise SystemExit("No recognizable result files found")

    id_sets = [set(d) for d in by_version.values()]
    all_ids = sorted(set().union(*id_sets))
    if args.inner:
        all_ids = sorted(set.intersection(*id_sets)) if len(id_sets) > 1 else all_ids
        print(f"[merge] Inner mode: {len(all_ids)} common record_ids")
    else:
        print(f"[merge] Union mode: {len(all_ids)} total records")

    # Unified ground truth: process in 0/1/2/4class order; fine-grained overwrites coarse-grained derivations
    gt_table = {}
    for v in VERSIONS:
        if v not in by_version:
            continue
        for rid, r in by_version[v].items():
            gt_table.setdefault(rid, {})
            merge_gt(gt_table[rid], unified_gt(r))

    # ---- Assemble table header ----
    header = ["question_id", "record_id", "side"] + GT_COLUMNS
    for v in VERSIONS:
        if v not in by_version:
            continue
        for d in VERSION_DIMS[v]:
            header.append(f"{v}:{d}")
        header += [
            f"{v}:pred_error(1=err)",
            f"{v}:2way_correct",
            f"{v}:exact_match",
            f"{v}:avg_p_plus",
            f"{v}:parsed(1=yes)",
        ]

    
    table = []
    for rid in all_ids:
        gt = gt_table.get(rid, {})
        row = [
            meta[rid]["question_id"], rid, meta[rid]["side"],
        ] + [gt.get(c[3:], "") for c in GT_COLUMNS]
        for v in VERSIONS:
            if v not in by_version:
                continue
            r = by_version[v].get(rid)
            if r is None:
                row += [""] * (len(VERSION_DIMS[v]) + 5)
                continue
            pd = r["predicted"] or {}
            for d in VERSION_DIMS[v]:
                row.append(pd.get(d, ""))
            p_err = pred_error_flag(r)
            two_way = (
                int(gt.get("error") == p_err)
                if p_err is not None and "error" in gt else ""
            )
            p_plus = r.get("p_plus") or {}
            avg_p = (round(sum(p_plus.values()) / len(p_plus), 4)
                     if p_plus else "")
            row += [
                p_err if p_err is not None else "",
                two_way, int(bool(r.get("exact_match"))),
                avg_p, int(r.get("predicted") is not None),
            ]
        table.append(row)

    
    out_stem = args.output
    if not os.path.splitext(out_stem)[1]:
        out_dir = os.path.dirname(args.output)
        if not out_dir and args.files is None:
            out_stem = os.path.join(args.result_dir, os.path.basename(out_stem))
    csv_path = out_stem + ".csv"
    os.makedirs(os.path.dirname(os.path.abspath(csv_path)), exist_ok=True)
    with open(csv_path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(table)
    print(f"[save] {csv_path} ({len(table)} rows x {len(header)} cols)")

    
    try:
        from openpyxl import Workbook
        from openpyxl.styles import PatternFill, Font
    except ImportError:
        print("[info] openpyxl not installed, skipping xlsx (pip install openpyxl to generate)")
        return

    wb = Workbook()
    ws = wb.active
    ws.title = "merged_results"
    ws.append(header)
    for c in ws[1]:
        c.font = Font(bold=True)
    green = PatternFill("solid", fgColor="C6EFCE")
    red = PatternFill("solid", fgColor="FFC7CE")
    two_way_cols = [i for i, h in enumerate(header) if h.endswith(":2way_correct")]

    for row in table:
        ws.append(row)
        xrow = ws.max_row
        for ci in two_way_cols:
            v = row[ci]
            if v == 1:
                ws.cell(xrow, ci + 1).fill = green
            elif v == 0:
                ws.cell(xrow, ci + 1).fill = red
    ws.freeze_panes = "L2"  # Freeze metadata (3 cols) + unified ground truth (8 cols) and header
    xlsx_path = out_stem + ".xlsx"
    wb.save(xlsx_path)
    print(f"[save] {xlsx_path} (2way cols: green=correct, red=incorrect; metadata + ground truth cols and header frozen)")


if __name__ == "__main__":
    main()
