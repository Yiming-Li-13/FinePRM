# -*- coding: utf-8 -*-
"""0/1/2class (optional 4class) local LoRA training + testing pipeline.

For each version, sequentially executes:
  1) Train: python train_.py --versions <v> --output_dir outputs/lora_<v>
  2) Test:  python test_local_lora.py --model_dir outputs/lora_<v>
           --version <v> --output test_results/<v>_results.jsonl
  3) Aggregate: after all versions finish, run compute_metrics.py to generate comparison table

All versions share the same validation split (val_question_ids.json), the same seed,
and the same hyper-parameters, ensuring "error-label granularity" is the only variable.

Usage:
  python run_all.py                      # Train and test 0/1/2/4class (controlled comparison on same base)
  python run_all.py --versions 0class 1class 2class 4class
  python run_all.py --quick_test         # Smoke test: small samples + 1 epoch per version
  python run_all.py --skip_train         # Only re-test existing LoRA adapters
  python run_all.py --skip_test          # Only train
  python run_all.py --epochs 4 --batch_size 2 --grad_accum 16  # Save memory on T4
"""
import argparse
import subprocess
import sys
import os
import time

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PYTHON = sys.executable


def run_step(cmd, log_path):
    """Execute one step, stream output in real-time while writing to log file. Abort on failure."""
    print("\n" + "#" * 78)
    print("# CMD:", " ".join(cmd))
    print("# LOG:", log_path)
    print("#" * 78 + "\n", flush=True)
    t0 = time.time()
    with open(log_path, "w", encoding="utf-8") as logf:
        proc = subprocess.Popen(
            cmd, cwd=BASE_DIR, stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT, text=True, bufsize=1,
        )
        for line in proc.stdout:
            print(line, end="")
            logf.write(line)
        proc.wait()
    dt = time.time() - t0
    if proc.returncode != 0:
        print(f"\n[FAIL] Step failed (took {dt/60:.1f} min), see log: {log_path}")
        sys.exit(proc.returncode)
    print(f"\n[OK] Step completed, took {dt/60:.1f} min")


def main():
    ap = argparse.ArgumentParser(description="0/1/2/4class training + testing pipeline")
    ap.add_argument("--versions", nargs="+",
                    default=["0class", "1class", "2class", "4class"],
                    choices=["0class", "1class", "2class", "4class"])
    ap.add_argument("--output_root", default="outputs",
                    help="LoRA output root directory (each version under lora_<v>)")
    ap.add_argument("--result_dir", default="test results",
                    help="Test result directory (<v>_results.jsonl)")
    ap.add_argument("--skip_train", action="store_true")
    ap.add_argument("--skip_test", action="store_true")
    ap.add_argument("--skip_metrics", action="store_true",
                    help="Do not auto-generate comparison table after completion")
    ap.add_argument("--quick_test", action="store_true",
                    help="Smoke mode: small samples + 1 epoch per version")
    ap.add_argument("--epochs", type=float, default=4.0)
    ap.add_argument("--batch_size", type=int, default=4)
    ap.add_argument("--grad_accum", type=int, default=8)
    ap.add_argument("--lr", type=float, default=1e-4)
    ap.add_argument("--max_length", type=int, default=3072,
                    help="Max token length for training (reduce to 1024 to save memory; covers ~98%% of samples)")
    ap.add_argument("--max_train_samples", type=int, default=None,
                    help="Use only the first N training rows per version (small-sample experiments)")
    ap.add_argument("--max_val_samples", type=int, default=None,
                    help="Use at most the first N validation rows per version (default: full validation set)")
    ap.add_argument("--hf_mirror", action="store_true",
                    help="Download base model via hf-mirror.com during training")
    ap.add_argument("--eval_batch_size", type=int, default=8)
    args = ap.parse_args()

    os.makedirs(os.path.join(BASE_DIR, args.output_root), exist_ok=True)
    os.makedirs(os.path.join(BASE_DIR, args.result_dir), exist_ok=True)
    log_dir = os.path.join(BASE_DIR, "logs")
    os.makedirs(log_dir, exist_ok=True)

    for v in args.versions:
        model_dir = os.path.join(args.output_root, f"lora_{v}")
        result_file = os.path.join(args.result_dir, f"{v}_results.jsonl")
        print(f"\n==================== {v} ====================")

        # ---- Training ----
        if not args.skip_train:
            train_cmd = [
                PYTHON, "train_.py",
                "--versions", v,
                "--output_dir", model_dir,
                "--num_train_epochs", str(args.epochs),
                "--per_device_train_batch_size", str(args.batch_size),
                "--gradient_accumulation_steps", str(args.grad_accum),
                "--learning_rate", str(args.lr),
                "--max_length", str(args.max_length),
                "--per_device_eval_batch_size", str(args.eval_batch_size),
            ]
            if args.max_train_samples is not None:
                train_cmd += ["--max_train_samples", str(args.max_train_samples)]
            if args.max_val_samples is not None:
                train_cmd += ["--max_val_samples", str(args.max_val_samples)]
            if args.quick_test:
                train_cmd.append("--quick_test")
            if args.hf_mirror:
                train_cmd.append("--hf_mirror")
            run_step(train_cmd, os.path.join(log_dir, f"train_{v}.log"))

        # ---- Testing (evaluate stage1 error labels by default; 0class auto single) ----
        if not args.skip_test:
            stage = 0 if v == "0class" else 1
            test_cmd = [
                PYTHON, "test_local_lora.py",
                "--model_dir", model_dir,
                "--version", v,
                "--stage", str(stage),
                "--output", result_file,
                "--batch_size", str(args.eval_batch_size),
                "--max_length", str(args.max_length),
            ]
            run_step(test_cmd, os.path.join(log_dir, f"test_{v}.log"))

    # ---- Aggregate comparison table ----
    if not args.skip_metrics:
        metrics_cmd = [
            PYTHON, "compute_metrics.py",
            "--result_dir", args.result_dir,
        ]
        run_step(metrics_cmd, os.path.join(log_dir, "metrics.log"))

    print("\n[ALL DONE] Pipeline finished for all versions.")
    print(f"  LoRA weights : {args.output_root}/lora_<version>/")
    print(f"  Test results : {args.result_dir}/<version>_results.jsonl")
    if not args.skip_metrics:
        print(f"  Comparison table : {args.result_dir}/comparison_table.md")


if __name__ == "__main__":
    main()
