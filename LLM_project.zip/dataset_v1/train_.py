# -*- coding: utf-8 -*-
"""
PathFinder-PRM reproduction — single-model training script (teammate B)

Goal
----
Mix the data of four error-label granularities (0/1/2/4:
prm_0class.jsonl / prm_1class.jsonl / prm_2class.jsonl /
prm_4class.jsonl) **together to train one single model**.

The trained model is a "grading model" (not an answering model): given
"question + several steps of a student's solution", it outputs <+>
(correct / no issue on this dimension) or <-> (incorrect / issue on this
dimension) at each position to be judged. The softmax probability of the
two is the judgment confidence (the probability of <+> can also serve
directly as a reward score).

Why the four files can be trained together
------------------------------------------
* In each row's inputs, the positions whose labels are to be predicted are
  uniformly written as the placeholder <extra> (1/2/4 per row, varying);
* The ground truth has only the two tokens <+>/<->; what each version is
  "judging" is distinguished by the row's own system prompt text
  (Correctness / Error / Math reasoning / Consistency / Calculation / ...),
  and the model relies on the prompt to understand the semantics of the
  current <extra> position;
* Therefore the training objective is identical across the four versions:
  only at the <extra> positions, take the logits at the same positions and
  compute cross-entropy against the ground truth <+>/<-> (the masked
  prediction of paper Appendix C, not autoregressive next-token); all other
  positions are masked with -100;
* For 1/2/4-class, the stage=2 rows substitute the stage-1 ground truth
  into the text (as context), leaving only one Correctness <extra>,
  naturally realizing the paper's "two forward passes / two-stage decoupled"
  supervision.

Data scale: 0class 2330 rows + 1/2/4class 4660 rows each = 16310 rows total.
Validation set: split by question groups using val_question_ids.json
(the four versions share the same split).

Usage
----
# 1) Train (default: use all four versions, output to outputs/lora_judge)
python train_.py
# Train only some versions (for ablation experiments)
python train_.py --versions 0class 4class --output_dir outputs/lora_sub
# One-click smoke test (small sample + 1 epoch, verify it can run through)
python train_.py --quick_test

# 2) Use the trained model to judge a new piece of data (messages JSON
#    format matches the inputs field of training data; the assistant
#    content must end with the <extra> placeholder)
python train_.py --mode predict --model_dir outputs/lora_judge \
    --predict_json one_case.json

one_case.json example (0-class format, judging Correctness):
{
  "messages": [
    {"role": "user", "content": "You are a Math Teacher. ... Question: ..."},
    {"role": "assistant", "content": "Step 1\n\nStep 2\n\nCurrent Step: ... Correctness: <extra>"}
  ]
}
The output gives the <+>/<-> judgment and probability for each <extra>
position (a single message may contain multiple <extra>).

When GPU memory is insufficient (T4 16G is tight):
  --per_device_train_batch_size 2 --gradient_accumulation_steps 16
"""

import argparse
import importlib
import json
import os
from typing import Any, Dict, List, Optional

os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import Dataset

from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    Trainer,
    TrainingArguments,
    set_seed,
)
from peft import LoraConfig, PeftModel, TaskType, get_peft_model

# --------------------------------------------------------------------------- #
# Constants
# --------------------------------------------------------------------------- #
LABEL_POSITIVE = "<+>"
LABEL_NEGATIVE = "<->"
MASK_TOKEN = "<extra>"
NEW_TOKENS = [LABEL_POSITIVE, LABEL_NEGATIVE, MASK_TOKEN]

ALL_VERSIONS = ["0class", "1class", "2class", "4class"]

# stage original value (string "single"/"1"/"2", also accepts int) -> group id
STAGE_TO_GROUP = {"single": 0, "1": 1, 1: 1, "2": 2, 2: 2}
STAGE_NAMES = {0: "single_correctness", 1: "stage1_error_labels", 2: "stage2_correctness"}


# --------------------------------------------------------------------------- #
# Data
# --------------------------------------------------------------------------- #
class PRMDataset(Dataset):
    """Read JSONL rows (possibly from multiple versions), tokenize and cache.

    Each sample produces:
      input_ids      : id sequence after rendering and tokenizing inputs (incl. <extra>)
      target_mask    : bool sequence, True at <extra> positions that need loss
      target_labels  : long sequence, the ground truth <+>/<-> at target_mask
                       positions, -100 elsewhere
      stage_group    : 0/1/2, for evaluation grouping
      version_idx    : index of the version in VERSIONS list, for evaluation grouping
      length / n_targets / id
    """

    def __init__(self, rows: List[dict], tokenizer, max_length: int,
                 version_to_idx: Dict[str, int]):
        self.examples: List[Dict[str, Any]] = []
        self.skipped_long = 0

        extra_id = tokenizer.convert_tokens_to_ids(MASK_TOKEN)
        plus_id = tokenizer.convert_tokens_to_ids(LABEL_POSITIVE)
        minus_id = tokenizer.convert_tokens_to_ids(LABEL_NEGATIVE)

        for row in rows:
            input_ids = tokenizer.apply_chat_template(
                row["inputs"], tokenize=True, add_generation_prompt=False
            )
            label_ids = tokenizer.apply_chat_template(
                row["labels"], tokenize=True, add_generation_prompt=False
            )

            # inputs and labels differ only where <extra> -> <+>/<->; all three are
            # single tokens, so their tokenized lengths must be equal, otherwise the
            # position alignment will be misaligned
            if len(input_ids) != len(label_ids):
                raise ValueError(
                    f"Row {row.get('id')} has mismatched inputs/labels tokenized lengths: "
                    f"{len(input_ids)} vs {len(label_ids)}"
                )
            if len(input_ids) > max_length:
                self.skipped_long += 1
                continue

            target_mask = [tid == extra_id for tid in input_ids]
            n_targets = sum(target_mask)
            if n_targets == 0:
                raise ValueError(f"Row {row.get('id')} inputs has no <extra> placeholder")

            target_labels = [-100] * len(input_ids)
            for i, is_target in enumerate(target_mask):
                if is_target:
                    gold = label_ids[i]
                    if gold not in (plus_id, minus_id):
                        raise ValueError(
                            f"Row {row.get('id')} position {i} ground truth token is not <+>/<->: {gold}"
                        )
                    target_labels[i] = gold

            self.examples.append(
                {
                    "input_ids": input_ids,
                    "target_mask": target_mask,
                    "target_labels": target_labels,
                    "stage_group": STAGE_TO_GROUP.get(row.get("stage"), 0),
                    "version_idx": version_to_idx[row["version"]],
                    "length": len(input_ids),
                    "n_targets": n_targets,
                    "id": row.get("id"),
                }
            )

    def __len__(self):
        return len(self.examples)

    def __getitem__(self, i):
        return self.examples[i]


class PRMDataCollator:
    """Right-side padding; padding positions have attention_mask=0, target_mask=False."""

    def __init__(self, pad_token_id: int):
        self.pad_token_id = pad_token_id

    def __call__(self, features: List[Dict[str, Any]]):
        max_len = max(len(f["input_ids"]) for f in features)
        input_ids, attn, mask, labels, stages, vers = [], [], [], [], [], []
        for f in features:
            pad_n = max_len - len(f["input_ids"])
            input_ids.append(f["input_ids"] + [self.pad_token_id] * pad_n)
            attn.append([1] * len(f["input_ids"]) + [0] * pad_n)
            mask.append(f["target_mask"] + [False] * pad_n)
            labels.append(f["target_labels"] + [-100] * pad_n)
            # Each target position carries the row's grouping info
            # (in one-to-one correspondence with the target order)
            stages.extend([f["stage_group"]] * f["n_targets"])
            vers.extend([f["version_idx"]] * f["n_targets"])
        return {
            "input_ids": torch.tensor(input_ids, dtype=torch.long),
            "attention_mask": torch.tensor(attn, dtype=torch.long),
            "target_mask": torch.tensor(mask, dtype=torch.bool),
            "target_labels": torch.tensor(labels, dtype=torch.long),
            "stage_groups": torch.tensor(stages, dtype=torch.long),
            "version_groups": torch.tensor(vers, dtype=torch.long),
        }


def load_split_rows(data_dir: str, versions: List[str],
                    max_train_per_version: Optional[int] = None,
                    max_val_per_version: Optional[int] = None):
    """Read JSONL of multiple versions, split by question groups via val_question_ids.json.

    Returns (train_rows, val_rows), each row carries a version field; when an upper
    limit is given, only the first N rows of each version's file are taken
    (for quick_test / small-sample experiments; row order is stable and reproducible).
    """
    with open(os.path.join(data_dir, "val_question_ids.json"), encoding="utf-8") as f:
        val_qids = set(json.load(f)["val_question_ids"])

    train_rows, val_rows = [], []
    counts = {}
    for v in versions:
        n_tr = n_va = 0
        path = os.path.join(data_dir, f"prm_{v}.jsonl")
        with open(path, encoding="utf-8") as f:
            for line in f:
                row = json.loads(line)
                is_val = row["question_id"] in val_qids
                if is_val:
                    if max_val_per_version is not None and n_va >= max_val_per_version:
                        continue
                    n_va += 1
                    val_rows.append(row)
                else:
                    if max_train_per_version is not None and n_tr >= max_train_per_version:
                        continue
                    n_tr += 1
                    train_rows.append(row)
        counts[v] = (n_tr, n_va)
    return train_rows, val_rows, counts


# --------------------------------------------------------------------------- #
# Custom Trainer: only compute CE at <extra> positions
# --------------------------------------------------------------------------- #
class PRMTrainer(Trainer):
    """
    Loss (paper §3.4 "cross-entropy loss only on these label tokens"):
      logits are taken at the same <extra> position (masked prediction, not
      next-token), and CE is computed against the ground truth <+>/<->.
      loss_reduction="token"  : average over all target positions in the batch;
                       "sample": first average each row over its 1/2/4 targets,
                              then average over rows (so that under four-version
                              joint training, a single sample from 0class and
                              from 4class carry equal weight).

    Evaluation:
      eval_ce_full   : full-vocabulary CE (= training loss definition)
      eval_ce_binary : CE re-softmaxed only over the two tokens <+>/<-> (matches inference)
      eval_2way_acc  : argmax accuracy over the two-way <+>/<-> choice
                       (primary metric, used to select the best checkpoint)
      Also reports grouped accuracy by version × stage, as well as positive/negative
      hit rates.
    """

    def __init__(self, *args, plus_id: int, minus_id: int,
                 loss_reduction: str = "token", **kwargs):
        super().__init__(*args, **kwargs)
        self.plus_id = plus_id
        self.minus_id = minus_id
        self.loss_reduction = loss_reduction

    def log(self, logs, start_time=None):
        # Trainer's own eval_loss is "average over batches then average again"; when
        # the number of targets per batch differs (1/2/4) it becomes biased. Unify it
        # to the per-target-averaged eval_ce_full computed in compute_metrics, so
        # that in logs eval_loss == eval_ce_full.
        if "eval_ce_full" in logs and "eval_loss" in logs:
            logs["eval_loss"] = logs["eval_ce_full"]
        super().log(logs, start_time)

    @staticmethod
    def _causal_core(model):
        """Extract the CausalLM body from the PeftModel wrapper (incl. .model trunk and .lm_head)."""
        base = getattr(model, "base_model", model)   # PeftModel -> LoraModel
        return getattr(base, "model", base)          # LoraModel -> CausalLM

    def _select_target_logits(self, model, inputs):
        # Memory optimization: only compute lm_head at the M <extra> target positions
        # (only 1~4 per row), instead of materializing logits of the full sequence ×
        # 150k vocab (saves ~0.8GB peak at length 768).
        # Mathematically equivalent to taking outputs.logits[mask] directly
        # (tied weights, same forward path).
        causal = self._causal_core(model)
        hidden = causal.model(
            input_ids=inputs["input_ids"],
            attention_mask=inputs["attention_mask"],
        ).last_hidden_state                            # (B, L, H)
        mask = inputs["target_mask"]  # (B, L)
        gold = inputs["target_labels"][mask]  # (M,)
        # Under fp16 (T4/MPS), softmax over the 150k vocab may overflow; upcast to fp32
        return causal.lm_head(hidden[mask]).float(), gold

    def compute_loss(self, model, inputs, return_outputs=False, num_items_in_batch=None):
        target_logits, gold = self._select_target_logits(model, inputs)
        if self.loss_reduction == "token":
            loss = F.cross_entropy(target_logits, gold)
        else:
            # First average each row over its 1/2/4 targets, then average over rows in the batch
            per_ce = F.cross_entropy(target_logits, gold, reduction="none")
            row_idx = inputs["target_mask"].nonzero(as_tuple=False)[:, 0]
            row_idx = row_idx.to(per_ce.device)
            n_rows = inputs["input_ids"].size(0)
            sums = torch.zeros(n_rows, device=per_ce.device).scatter_add(0, row_idx, per_ce)
            counts = torch.zeros(n_rows, device=per_ce.device).scatter_add(
                0, row_idx, torch.ones_like(per_ce)
            )
            loss = (sums / counts.clamp_min(1)).mean()
        return (loss, {"logits": target_logits}) if return_outputs else loss

    @torch.no_grad()
    def prediction_step(self, model, inputs, prediction_loss_only, ignore_keys=None):
        inputs = self._prepare_inputs(inputs)
        target_logits, gold = self._select_target_logits(model, inputs)
        loss = F.cross_entropy(target_logits, gold)

        ce_full = F.cross_entropy(target_logits, gold, reduction="none")
        # Column order [minus, plus], consistent with the target (gold==plus) class id: 0=<->, 1=<+>
        binary_logits = target_logits[:, [self.minus_id, self.plus_id]]
        ce_binary = F.cross_entropy(
            binary_logits, (gold == self.plus_id).long(), reduction="none"
        )
        # preds (M, 4): <-> binary logit, <+> binary logit, full-vocab CE, binary CE
        preds = torch.stack(
            [binary_logits[:, 0], binary_logits[:, 1], ce_full, ce_binary], dim=1
        )
        # labels (M, 3): gold01 (1=<+>), stage_group, version_idx
        labels = torch.stack(
            [
                (gold == self.plus_id).long(),
                inputs["stage_groups"].long(),
                inputs["version_groups"].long(),
            ],
            dim=1,
        )
        return loss.detach(), preds.detach().float(), labels.detach()


def compute_metrics_factory(versions: List[str]):
    def compute_metrics(eval_pred):
        preds = eval_pred.predictions  # (M, 4)
        labels = eval_pred.label_ids  # (M, 3)
        gold01 = labels[:, 0].astype(np.int64)
        stages = labels[:, 1].astype(np.int64)
        vers = labels[:, 2].astype(np.int64)

        pred01 = (preds[:, 1] > preds[:, 0]).astype(np.int64)  # 1 = predicted <+>
        correct = pred01 == gold01

        # eval_loss and eval_ce_full are unified to "averaged over target positions"
        # (overrides Trainer's default per-batch-averaged eval_loss, avoiding the
        # bias caused by differing target counts per batch)
        metrics = {
            "eval_loss": float(np.mean(preds[:, 2])),
            "eval_ce_full": float(np.mean(preds[:, 2])),
            "eval_ce_binary": float(np.mean(preds[:, 3])),
            "eval_2way_acc": float(correct.mean()),
            "n_targets": int(len(gold01)),
            "gold_positive_rate": float(gold01.mean()),
        }
        # By version
        for vi, vname in enumerate(versions):
            sel = vers == vi
            if sel.any():
                metrics[f"acc::{vname}"] = float(correct[sel].mean())
        # By version × stage
        for vi, vname in enumerate(versions):
            for g in sorted(set(stages[vers == vi].tolist())) if (vers == vi).any() else []:
                sel = (vers == vi) & (stages == g)
                metrics[f"acc::{vname}::{STAGE_NAMES.get(g, g)}"] = float(correct[sel].mean())
        # Hit rates for positive / negative examples separately (<+> = positive)
        metrics["recall::positive_<+>"] = (
            float(correct[gold01 == 1].mean()) if (gold01 == 1).any() else -1.0
        )
        metrics["recall::negative_<->"] = (
            float(correct[gold01 == 0].mean()) if (gold01 == 0).any() else -1.0
        )
        return metrics

    return compute_metrics


# --------------------------------------------------------------------------- #
# Model construction
# --------------------------------------------------------------------------- #
def pick_attn_impl():
    if importlib.util.find_spec("flash_attn") is not None:
        return "flash_attention_2"
    return "sdpa"


def pick_dtype(arg: Optional[str]):
    """Returns (torch_dtype, use_bf16, use_fp16)."""
    if arg == "bf16":
        return torch.bfloat16, torch.cuda.is_available(), False
    if arg == "fp16":
        return torch.float16, False, torch.cuda.is_available()
    if arg == "fp32":
        return torch.float32, False, False
    # Auto: A100/L4 etc. use bf16; T4 (SM7.5) does not support bf16, falls back to fp16;
    # Apple MPS uses fp16 weights but does not enable Trainer's CUDA AMP (MPS has no
    # GradScaler); CPU uses fp32
    if torch.cuda.is_available():
        if torch.cuda.is_bf16_supported():
            return torch.bfloat16, True, False
        return torch.float16, False, True
    if torch.backends.mps.is_available():
        return torch.float16, False, False
    return torch.float32, False, False


def add_special_tokens(tokenizer):
    """Step 1: register the three single tokens <+>/<->/<extra> (skip if already present)."""
    added = tokenizer.add_tokens(
        [t for t in NEW_TOKENS if t not in tokenizer.get_vocab()],
        special_tokens=False,
    )
    for t in NEW_TOKENS:
        enc = tokenizer.encode(t, add_special_tokens=False)
        assert len(enc) == 1, f"{t} was not split into a single token: {enc}"
    print(f"[tokenizer] added {added} tokens, vocab size {len(tokenizer)}")
    return added


def attach_new_token_deltas(peft_model, tokenizer):
    """Memory-saving new-token training scheme (runnable on 8GB MPS).

    Full training of embed_tokens/lm_head (233M rows) needs ~1.8GB just for the
    optimizer/gradient temporaries on MPS. Instead: freeze the whole vocab, and
    for the three new rows <+>/<->/<extra> add an fp32 zero-initialized delta
    (3×hidden, totaling 9216 params) injected via forward hooks:
      * in the embedding output, at the new-token positions += embed_delta;
      * in the lm_head output, at the three new-token columns += hidden @ head_delta.T.
    Zero initialization guarantees the start point matches the randomly resized row
    exactly; the delta can learn any correction, so the expressive power equals
    training these three rows directly (final row = frozen init + delta).
    Returns {"embed": p, "lm_head": p, "first_id": int}.
    """
    import torch.nn.functional as _F
    new_ids = [tokenizer.convert_tokens_to_ids(t) for t in NEW_TOKENS]
    assert new_ids == list(range(min(new_ids), min(new_ids) + 3)), \
        f"The three new tokens are not contiguous IDs: {new_ids}"
    first_id = min(new_ids)

    causal = peft_model.base_model.model           # Qwen2ForCausalLM
    qwen = causal.model                            # Qwen2Model
    hidden = causal.config.hidden_size
    device = causal.lm_head.weight.device

    d_emb = torch.nn.Parameter(torch.zeros(3, hidden, dtype=torch.float32,
                                           device=device))
    d_head = torch.nn.Parameter(torch.zeros(3, hidden, dtype=torch.float32,
                                            device=device))
    peft_model.new_embed_delta = d_emb
    peft_model.new_lmhead_delta = d_head

    def emb_hook(module, inp, output):
        ids = inp[0]
        m = (ids >= first_id).unsqueeze(-1).to(output.dtype)
        add = d_emb[(ids - first_id).clamp_min(0)].to(output.dtype)
        return output + add * m

    def head_hook(module, inp, output):
        h = inp[0]
        add3 = h.to(torch.float32) @ d_head.t()    # (..., 3)
        # Pad the three delta columns to the vocab width at their corresponding positions
        vocab = output.shape[-1]
        add_full = _F.pad(
            add3.to(output.dtype),
            (first_id, vocab - first_id - 3),
        )
        return output + add_full

    qwen.embed_tokens.register_forward_hook(emb_hook)
    causal.lm_head.register_forward_hook(head_hook)
    return {"embed": d_emb, "lm_head": d_head, "first_id": first_id}


def save_new_token_deltas(peft_model, path):
    from safetensors.torch import save_file
    save_file({
        "new_embed_delta": peft_model.new_embed_delta.detach().cpu(),
        "new_lmhead_delta": peft_model.new_lmhead_delta.detach().cpu(),
    }, path)


def load_new_token_deltas(peft_model, tokenizer, path):
    from safetensors.torch import load_file
    saved = load_file(path)
    info = attach_new_token_deltas(peft_model, tokenizer)
    device = info["embed"].device
    peft_model.new_embed_delta.data = saved["new_embed_delta"].to(device)
    peft_model.new_lmhead_delta.data = saved["new_lmhead_delta"].to(device)
    return info


def build_model_and_tokenizer(args):
    tokenizer = AutoTokenizer.from_pretrained(args.model_name_or_path)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    add_special_tokens(tokenizer)

    dtype, use_bf16, use_fp16 = pick_dtype(args.dtype)
    model = AutoModelForCausalLM.from_pretrained(
        args.model_name_or_path,
        torch_dtype=dtype,
        attn_implementation=pick_attn_impl(),
    )
    # Expand embedding / lm_head (new rows initialized from the old embedding
    # distribution; transformers' default behavior)
    model.resize_token_embeddings(len(tokenizer))
    model.config.use_cache = False
    # Under gradient checkpointing, keep the input embedding differentiable
    # (must be called before the PEFT wrapper)
    model.enable_input_require_grads()

    # LoRA: only attach 7 linear projections; the vocab is frozen, and the three
    # new rows <+>/<->/<extra> are trained via zero-initialized deltas
    # (attach_new_token_deltas) — expressively equivalent to fully training
    # these three rows with modules_to_save, but trainable on 8GB of GPU memory
    # (avoids the fp32 optimizer state/gradient temporaries of 233M params).
    # All platforms (CUDA/MPS/CPU) use this scheme, so the saved artifacts are
    # consistent and comparable.
    lora_config = LoraConfig(
        task_type=TaskType.CAUSAL_LM,
        r=args.lora_r,
        lora_alpha=args.lora_alpha,
        lora_dropout=args.lora_dropout,
        bias="none",
        target_modules=[
            "q_proj", "k_proj", "v_proj", "o_proj",
            "gate_proj", "up_proj", "down_proj",
        ],
    )
    model = get_peft_model(model, lora_config)
    attach_new_token_deltas(model, tokenizer)
    model.print_trainable_parameters()
    return model, tokenizer, (use_bf16, use_fp16)


def load_judger(model_dir: str, dtype_arg: str = "auto"):
    """Load the trained grading model: base + LoRA adapter + tokenizer containing the new tokens."""
    with open(os.path.join(model_dir, "train_meta.json"), encoding="utf-8") as f:
        meta = json.load(f)
    # Normal path: the adapter directory ships a tokenizer + config.json containing
    # <+>/<->/<extra>.
    # Fallback path: legacy directories missing config.json — load the tokenizer
    # from the base model and re-register the new tokens.
    try:
        tokenizer = AutoTokenizer.from_pretrained(model_dir)
    except (ValueError, OSError):
        print(f"[load] {model_dir} is missing config.json; loading tokenizer from base "
              f"{meta['base_model']} and re-registering new tokens")
        tokenizer = AutoTokenizer.from_pretrained(meta["base_model"])
        if tokenizer.pad_token is None:
            tokenizer.pad_token = tokenizer.eos_token
        add_special_tokens(tokenizer)
    base = meta["base_model"]
    dtype, _, _ = pick_dtype(dtype_arg)
    model = AutoModelForCausalLM.from_pretrained(
        base, torch_dtype=dtype, attn_implementation=pick_attn_impl()
    )
    model.resize_token_embeddings(len(tokenizer))
    model = PeftModel.from_pretrained(model, model_dir)
    # Load the new-token deltas (present in new-format model directories; legacy
    # modules_to_save directories do not have this file)
    delta_path = os.path.join(model_dir, "new_token_deltas.safetensors")
    if os.path.exists(delta_path):
        load_new_token_deltas(model, tokenizer, delta_path)
    else:
        print("[load] new_token_deltas.safetensors not found; "
              "loading via legacy modules_to_save full embedding weights")
    model.eval()
    if torch.cuda.is_available():
        model.cuda()
    elif torch.backends.mps.is_available():
        model.to("mps")
    return model, tokenizer


@torch.no_grad()
def judge_messages(model, tokenizer, messages: List[dict]) -> List[dict]:
    """Judge each <extra> position in a messages list (same format as training data inputs field).

    Returns {index, label, p_plus, p_minus} for each position; label ∈ {'<+>','<->'}.
    """
    extra_id = tokenizer.convert_tokens_to_ids(MASK_TOKEN)
    plus_id = tokenizer.convert_tokens_to_ids(LABEL_POSITIVE)
    minus_id = tokenizer.convert_tokens_to_ids(LABEL_NEGATIVE)

    input_ids = tokenizer.apply_chat_template(
        messages, tokenize=True, add_generation_prompt=False
    )
    mask_positions = [i for i, t in enumerate(input_ids) if t == extra_id]
    if not mask_positions:
        raise ValueError("assistant content must contain at least one <extra> placeholder")

    device = next(model.parameters()).device
    enc = torch.tensor([input_ids], dtype=torch.long, device=device)
    logits = model(enc).logits[0].float()  # (L, V)
    results = []
    for k, pos in enumerate(mask_positions):
        bin_logits = logits[pos, [minus_id, plus_id]]  # [minus, plus]
        probs = F.softmax(bin_logits, dim=-1).cpu().numpy()
        p_minus, p_plus = float(probs[0]), float(probs[1])
        results.append(
            {
                "target_index": k,
                "position": pos,
                "label": LABEL_POSITIVE if p_plus > p_minus else LABEL_NEGATIVE,
                "p_<+>": p_plus,
                "p_<->": p_minus,
            }
        )
    return results


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #
def parse_args():
    p = argparse.ArgumentParser(description="PathFinder-PRM four-version joint training of a single model")
    p.add_argument("--mode", choices=["train", "predict"], default="train")

    # Training / data
    p.add_argument("--versions", nargs="+", default=ALL_VERSIONS,
                   choices=ALL_VERSIONS,
                   help="Versions participating in training (default: all four, training one unified grading model)")
    p.add_argument("--data_dir", default=os.path.dirname(os.path.abspath(__file__)),
                   help="Directory containing the JSONL files and val_question_ids.json")
    p.add_argument("--model_name_or_path", default="Qwen/Qwen2.5-Math-1.5B-Instruct",
                   help="Base model (default: 1.5B version of the paper's base)")
    p.add_argument("--output_dir", default=os.path.join("outputs", "lora_judge"),
                   help="LoRA output directory")
    p.add_argument("--max_length", type=int, default=3072,
                   help="Maximum token length; this dataset's measured max ≈ 2703, default 3072 does not truncate")
    p.add_argument("--loss_reduction", choices=["token", "sample"], default="token",
                   help="token=average over all target positions; sample=per-row average first (equal per-sample weight across four versions / 1-4 targets)")
    p.add_argument("--dtype", choices=["auto", "bf16", "fp16", "fp32"], default="auto")

    # Hyperparameters (defaults align with paper Table 6: 4 epoch / cosine /
    # warmup 0.1 / grad-norm 1.0; LoRA lr uses the common 1e-4; the paper's 1e-5
    # is the setting for full fine-tuning of the 7B model)
    p.add_argument("--num_train_epochs", type=float, default=4.0)
    p.add_argument("--per_device_train_batch_size", type=int, default=4)
    p.add_argument("--per_device_eval_batch_size", type=int, default=8)
    p.add_argument("--gradient_accumulation_steps", type=int, default=8,
                   help="Combined with the default bs, effective batch=32")
    p.add_argument("--learning_rate", type=float, default=1e-4)
    p.add_argument("--weight_decay", type=float, default=0.0)
    p.add_argument("--warmup_ratio", type=float, default=0.1)
    p.add_argument("--max_grad_norm", type=float, default=1.0)
    p.add_argument("--lr_scheduler_type", default="cosine")
    p.add_argument("--optim", default="auto",
                   help="Optimizer: auto=adamw_torch on CUDA, adafactor on MPS/CPU "
                        "(factored state, 8GB RAM can run full-embedding training)")
    p.add_argument("--lora_r", type=int, default=16)
    p.add_argument("--lora_alpha", type=int, default=32)
    p.add_argument("--lora_dropout", type=float, default=0.05)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--early_stopping_patience", type=int, default=0,
                   help=">0 enables early stopping on eval_2way_acc; 0 trains all epochs")
    p.add_argument("--max_train_samples", type=int, default=None,
                   help="Cap the first N training rows per version (small-sample experiment; default unlimited)")
    p.add_argument("--max_val_samples", type=int, default=None,
                   help="Cap the first N validation rows per version (default: full validation set)")
    p.add_argument("--quick_test", action="store_true",
                   help="One-click smoke mode: only a few samples per version + 1 epoch, verify it can run through")
    p.add_argument("--resume_from_checkpoint", type=str, default=None,
                   help="Resume training from a checkpoint directory; pass True to auto-find the latest checkpoint under output_dir")
    p.add_argument("--hf_mirror", action="store_true",
                   help="Download the model via hf-mirror.com (add this when direct HF access from mainland China fails)")

    # Inference
    p.add_argument("--model_dir", default=None,
                   help="predict mode: saved LoRA directory (defaults to --output_dir)")
    p.add_argument("--predict_json", default=None,
                   help="predict mode: JSON file containing a messages array (same format as the inputs field)")
    return p.parse_args()


# --------------------------------------------------------------------------- #
# train
# --------------------------------------------------------------------------- #
def run_train(args):
    if args.hf_mirror:
        os.environ.setdefault("HF_ENDPOINT", "https://hf-mirror.com")

    # quick_test: take the same number of rows per version to ensure all four
    # versions and both stages are covered
    max_train = args.max_train_samples
    max_val = args.max_val_samples
    if args.quick_test:
        args.num_train_epochs = 1.0
        max_train = max_train or 8
        max_val = max_val or 8  # at most 8 train/val rows per version
        print(f"[quick_test] enabled: at most train={max_train}/val={max_val} rows per version, "
              "num_train_epochs=1")

    set_seed(args.seed)

    # ---- Data ----
    train_rows, val_rows, split_counts = load_split_rows(
        args.data_dir, args.versions,
        max_train_per_version=max_train,
        max_val_per_version=max_val,
    )
    print(f"[data] versions={args.versions}")
    for v, (n_tr, n_va) in split_counts.items():
        print(f"[data]   {v}: train {n_tr} rows / val {n_va} rows")
    print(f"[data] total: train {len(train_rows)} rows / val {len(val_rows)} rows")

    # ---- Model + tokenizer (vocab addition and resize done together) ----
    model, tokenizer, (use_bf16, use_fp16) = build_model_and_tokenizer(args)
    version_to_idx = {v: i for i, v in enumerate(args.versions)}

    # ---- tokenize ----
    train_ds = PRMDataset(train_rows, tokenizer, args.max_length, version_to_idx)
    val_ds = PRMDataset(val_rows, tokenizer, args.max_length, version_to_idx)
    print(f"[data] tokenize done: train {len(train_ds)} / val {len(val_ds)} "
          f"(over-length skipped train={train_ds.skipped_long}, val={val_ds.skipped_long})")
    if len(train_ds) == 0:
        raise SystemExit(
            f"Training set fully skipped under max_length={args.max_length}; increase --max_length"
        )
    if len(val_ds) == 0:
        raise SystemExit(
            f"Validation set fully skipped under max_length={args.max_length}; increase --max_length"
        )
    plus_id = tokenizer.convert_tokens_to_ids(LABEL_POSITIVE)
    minus_id = tokenizer.convert_tokens_to_ids(LABEL_NEGATIVE)
    print(f"[tokens] <+>={plus_id} <->={minus_id} "
          f"<extra>={tokenizer.convert_tokens_to_ids(MASK_TOKEN)}")

    # ---- Trainer ----
    targs = TrainingArguments(
        output_dir=args.output_dir,
        num_train_epochs=args.num_train_epochs,
        per_device_train_batch_size=args.per_device_train_batch_size,
        per_device_eval_batch_size=args.per_device_eval_batch_size,
        gradient_accumulation_steps=args.gradient_accumulation_steps,
        learning_rate=args.learning_rate,
        weight_decay=args.weight_decay,
        warmup_ratio=args.warmup_ratio,
        max_grad_norm=args.max_grad_norm,
        lr_scheduler_type=args.lr_scheduler_type,
        optim=("adamw_torch" if torch.cuda.is_available() else "adafactor")
              if args.optim == "auto" else args.optim,
        logging_steps=20,
        save_strategy="epoch",
        eval_strategy="epoch",
        save_total_limit=1,
        load_best_model_at_end=True,
        metric_for_best_model="eval_2way_acc",
        greater_is_better=True,
        bf16=use_bf16,
        fp16=use_fp16,
        gradient_checkpointing=True,
        gradient_checkpointing_kwargs={"use_reentrant": False},
        group_by_length=True,
        remove_unused_columns=False,
        # Under MPS/CPU, multi-process workers error out due to fork; only CUDA uses 2
        dataloader_num_workers=2 if torch.cuda.is_available() else 0,
        report_to=[],
        seed=args.seed,
        save_safetensors=True,
    )

    callbacks = []
    if torch.backends.mps.is_available():
        from transformers import TrainerCallback

        class _MPSCacheCleaner(TrainerCallback):
            def on_epoch_end(self, args, state, control, **kwargs):
                torch.mps.empty_cache()

            def on_evaluate(self, args, state, control, **kwargs):
                torch.mps.empty_cache()

        callbacks.append(_MPSCacheCleaner())
    if args.early_stopping_patience > 0:
        from transformers import EarlyStoppingCallback
        callbacks.append(
            EarlyStoppingCallback(early_stopping_patience=args.early_stopping_patience)
        )

    trainer = PRMTrainer(
        model=model,
        args=targs,
        train_dataset=train_ds,
        eval_dataset=val_ds,
        data_collator=PRMDataCollator(tokenizer.pad_token_id),
        compute_metrics=compute_metrics_factory(args.versions),
        callbacks=callbacks,
        plus_id=plus_id,
        minus_id=minus_id,
        loss_reduction=args.loss_reduction,
    )

    # ---- Resume ----
    resume = args.resume_from_checkpoint
    if resume:
        resume = True if resume.lower() == "true" else resume
        print(f"[resume] resuming from checkpoint: {resume}")
    trainer.train(resume_from_checkpoint=resume)

    # ---- Save the best LoRA + tokenizer + metrics / meta ----
    os.makedirs(args.output_dir, exist_ok=True)
    trainer.save_model(args.output_dir)
    # Deltas of the three new tokens (trainable params outside the LoRA,
    # must be saved separately)
    save_new_token_deltas(
        model, os.path.join(args.output_dir, "new_token_deltas.safetensors")
    )
    tokenizer.save_pretrained(args.output_dir)
    # PEFT only saves adapter files and does not write the base config.json; newer
    # transformers' AutoTokenizer.from_pretrained needs it to identify the tokenizer
    # class, so save a copy here
    model.config.save_pretrained(args.output_dir)

    final_metrics = trainer.evaluate()
    # The dict returned by evaluate() still carries Trainer's per-batch-averaged
    # eval_loss; correct it here too
    if "eval_ce_full" in final_metrics:
        final_metrics["eval_loss"] = final_metrics["eval_ce_full"]
    with open(os.path.join(args.output_dir, "final_eval_metrics.json"), "w",
              encoding="utf-8") as f:
        json.dump({k: float(v) for k, v in final_metrics.items()}, f,
                  ensure_ascii=False, indent=2)

    meta = {
        "versions": args.versions,
        "base_model": args.model_name_or_path,
        "new_tokens": {t: tokenizer.convert_tokens_to_ids(t) for t in NEW_TOKENS},
        "train_rows": len(train_ds),
        "val_rows": len(val_ds),
        "split_counts": split_counts,
        "skipped_long": {"train": train_ds.skipped_long, "val": val_ds.skipped_long},
        "seed": args.seed,
        "args": {k: str(v) for k, v in vars(args).items()},
    }
    with open(os.path.join(args.output_dir, "train_meta.json"), "w",
              encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)

    print(f"[done] LoRA saved to {args.output_dir}")
    print("[done] final validation metrics:")
    print(json.dumps(final_metrics, ensure_ascii=False, indent=2))


# --------------------------------------------------------------------------- #
# predict
# --------------------------------------------------------------------------- #
def run_predict(args):
    model_dir = args.model_dir or args.output_dir
    if not args.predict_json:
        raise SystemExit("predict mode requires --predict_json pointing to a messages JSON file")
    with open(args.predict_json, encoding="utf-8") as f:
        payload = json.load(f)
    messages = payload["messages"] if "messages" in payload else payload

    model, tokenizer = load_judger(model_dir, dtype_arg=args.dtype)
    results = judge_messages(model, tokenizer, messages)
    print(json.dumps(results, ensure_ascii=False, indent=2))


def main():
    args = parse_args()
    if args.mode == "predict":
        run_predict(args)
    else:
        run_train(args)


if __name__ == "__main__":
    main()
