# -*- coding: utf-8 -*-
"""Local LoRA grading model test script (universal for 0/1/2/4class).

Differences from the online API test script test_finetuned_qwen.py:
  * Model is local (base + LoRA adapter), direct forward pass;
  * Training uses masked prediction: feed inputs (with <extra> placeholders),
    take logits at the <extra> positions; no prime/judge guidance needed;
  * Evaluation samples are strictly from the same distribution as training:
    the validation split from the same val_question_ids.json.

Unified result protocol (aligned with test_results.jsonl for compute_metrics.py aggregation):
  Each JSON line: question_id / record_id / side / stage / version /
             ground_truth / predicted / per_dim_correct / exact_match /
             p_plus (p(<+>) at each target position)
  Last line: {"type": "summary", ...} metrics summary.
Label semantics:
  * Error-class dimensions (error / math / consistency / calculation / method /
    prior_step / domain) value 1 = ground truth or prediction is <-> (error present);
  * correctness dimension value 1 = <+> (step correct).

Usage:
  python test_local_lora.py --model_dir outputs/lora_2class --version 2class \
      --output test_results/2class_results.jsonl
  python test_local_lora.py --model_dir outputs/lora_2class --version 2class \
      --stage 2 --output test_results/2class_results_stage2.jsonl   # optional: evaluate stage2 correctness
"""
import argparse
import json
import os
from collections import defaultdict

import torch
import torch.nn.functional as F

# Reuse data/model components from the training script to ensure training-test alignment
from train_ import (
    LABEL_NEGATIVE,
    LABEL_POSITIVE,
    PRMDataCollator,
    PRMDataset,
    load_judger,
    load_split_rows,
)

# (version, stage_group) -> dimension names in order of target position appearance
# stage_group: 0=single(0class), 1=stage1 error labels, 2=stage2 correctness
VERSION_DIMS = {
    ("0class", 0): ["correctness"],
    ("1class", 1): ["error"],
    ("1class", 2): ["correctness"],
    ("2class", 1): ["math", "consistency"],
    ("2class", 2): ["correctness"],
    ("4class", 1): ["calculation", "method", "prior_step", "domain"],
    ("4class", 2): ["correctness"],
}
# Dimensions where 1=erroneous (1 means <-> present); correctness is the opposite (1 means <+> correct)
ERROR_DIMS = {
    "error", "math", "consistency",
    "calculation", "method", "prior_step", "domain",
}


def stage_group_of(row):
    s = row.get("stage")
    return {"single": 0, "1": 1, 1: 1, "2": 2, 2: 2}.get(s, 0)


def prf(tp, fp, fn):
    p = tp / (tp + fp) if tp + fp else 0.0
    r = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2 * p * r / (p + r) if p + r else 0.0
    return round(p, 4), round(r, 4), round(f1, 4)


@torch.no_grad()
def evaluate(model, tokenizer, examples, rows, dim_names, batch_size):
    """Batch forward pass on PRMDataset examples; returns (result row list, counters)."""
    collator = PRMDataCollator(tokenizer.pad_token_id)
    plus_id = tokenizer.convert_tokens_to_ids(LABEL_POSITIVE)
    minus_id = tokenizer.convert_tokens_to_ids(LABEL_NEGATIVE)
    device = next(model.parameters()).device

    results = []
    tp = defaultdict(int); fp = defaultdict(int); fn = defaultdict(int)
    correct = defaultdict(int); total = defaultdict(int)
    n_exact = 0

    for start in range(0, len(examples), batch_size):
        batch_ex = examples[start:start + batch_size]
        batch_rows = rows[start:start + batch_size]
        enc = collator(batch_ex)
        enc = {k: v.to(device) for k, v in enc.items()}
        # Memory optimization: only run lm_head on <extra> target positions (same path as train_.py, equivalent)
        base = getattr(model, "base_model", model)
        causal = getattr(base, "model", base)
        hidden = causal.model(
            input_ids=enc["input_ids"], attention_mask=enc["attention_mask"]
        ).last_hidden_state
        target_logits = causal.lm_head(hidden[enc["target_mask"]]).float()  # (M,V)
        bin_probs = F.softmax(
            target_logits[:, [minus_id, plus_id]], dim=-1
        )                                                       # (M, 2)
        gold_ids = enc["target_labels"][enc["target_mask"]]    # (M,)
        pred_plus = bin_probs[:, 1] > bin_probs[:, 0]
        gold_plus = gold_ids == plus_id

        # Unpack per row: row i has n_targets_i targets, in order of appearance
        flat = 0
        for ex, row in zip(batch_ex, batch_rows):
            n = ex["n_targets"]
            assert n == len(dim_names), (
                f"Row {row.get('id')} has {n} targets, mismatch with version config {dim_names}"
            )
            gt, pd, ok_map, p_plus_map = {}, {}, {}, {}
            exact = True
            for k, dname in enumerate(dim_names):
                g_is_plus = bool(gold_plus[flat + k])
                p_is_plus = bool(pred_plus[flat + k])
                p_plus_map[dname] = round(float(bin_probs[flat + k, 1]), 6)
                if dname in ERROR_DIMS:
                    # 1 = erroneous (<->)
                    gt[dname] = 0 if g_is_plus else 1
                    pd[dname] = 0 if p_is_plus else 1
                else:  # correctness: 1 = correct (<+>)
                    gt[dname] = 1 if g_is_plus else 0
                    pd[dname] = 1 if p_is_plus else 0
                is_ok = int(gt[dname] == pd[dname])
                ok_map[dname] = is_ok
                exact &= bool(is_ok)
                total[dname] += 1
                correct[dname] += is_ok
                if gt[dname] == 1 and pd[dname] == 1:
                    tp[dname] += 1
                elif gt[dname] == 0 and pd[dname] == 1:
                    fp[dname] += 1
                elif gt[dname] == 1 and pd[dname] == 0:
                    fn[dname] += 1
            flat += n
            n_exact += int(exact)

            results.append({
                "question_id": row["question_id"],
                "record_id": row.get("record_id"),
                "id": row.get("id"),
                "side": row.get("side"),
                "stage": row.get("stage"),
                "version": row.get("version"),
                "n_targets": n,
                "ground_truth": gt,
                "predicted": pd,
                "per_dim_correct": ok_map,
                "exact_match": exact,
                "p_plus": p_plus_map,
                "parse_success": True,
                "error": None,
            })

    counters = {
        "tp": tp, "fp": fp, "fn": fn, "correct": correct, "total": total,
        "n_exact": n_exact,
    }
    return results, counters


def main():
    ap = argparse.ArgumentParser(description="Local LoRA grading model test")
    ap.add_argument("--model_dir", required=True, help="LoRA output directory from training")
    ap.add_argument("--version", required=True,
                    choices=["0class", "1class", "2class", "4class"])
    ap.add_argument("--stage", type=int, default=1,
                    help="Evaluation stage: 0=0class single, 1=stage1 error labels (default), "
                         "2=stage2 correctness (save separately)")
    ap.add_argument("--output", required=True, help="Result jsonl output path")
    ap.add_argument("--data_dir",
                    default=os.path.dirname(os.path.abspath(__file__)))
    ap.add_argument("--batch_size", type=int, default=8)
    ap.add_argument("--max_length", type=int, default=3072,
                    help="Max token length (must match training; reduce to 1024 to save memory)")
    ap.add_argument("--dtype", choices=["auto", "bf16", "fp16", "fp32"],
                    default="auto")
    args = ap.parse_args()

    if args.version == "0class" and args.stage != 0:
        print("[warn] 0class only has single stage; automatically using --stage 0")
        args.stage = 0
    dim_names = VERSION_DIMS[(args.version, args.stage)]

    # Only take this version's validation set, then filter by stage
    _, val_rows, _ = load_split_rows(args.data_dir, [args.version])
    val_rows = [r for r in val_rows if stage_group_of(r) == args.stage]
    print(f"[data] {args.version} stage={args.stage} validation samples: {len(val_rows)} rows")

    model, tokenizer = load_judger(args.model_dir, dtype_arg=args.dtype)
    # Record base model and training method for comparison table provenance (confound traceability)
    with open(os.path.join(args.model_dir, "train_meta.json"),
              encoding="utf-8") as f:
        train_meta = json.load(f)
    base_model_name = train_meta.get("base_model", "unknown")
    version_to_idx = {args.version: 0}
    ds = PRMDataset(val_rows, tokenizer, max_length=args.max_length,
                    version_to_idx=version_to_idx)
    # PRMDataset corresponds to rows in order; rows skipped due to exceeding max_length must be removed in sync
    kept_ids = {ex["id"] for ex in ds.examples}
    kept_rows = [r for r in val_rows if r.get("id") in kept_ids]
    assert len(kept_rows) == len(ds.examples)
    print(f"[data] Actually evaluated: {len(ds.examples)} rows (skipped {ds.skipped_long} for exceeding max_length)")

    results, c = evaluate(
        model, tokenizer, ds.examples, kept_rows, dim_names, args.batch_size
    )

    metrics = {}
    for d in dim_names:
        p, r, f1 = prf(c["tp"][d], c["fp"][d], c["fn"][d])
        metrics[d] = {
            "accuracy": round(c["correct"][d] / c["total"][d], 4)
                         if c["total"][d] else 0.0,
            "precision": p, "recall": r, "f1": f1,
            "support": c["total"][d],
        }
    summary = {
        "type": "summary",
        "version": args.version,
        "stage": args.stage,
        "dim_names": dim_names,
        "model_dir": args.model_dir,
        "base_model": base_model_name,
        "training_method": "LoRA",
        "n_records": len(results),
        "n_skipped_long": ds.skipped_long,
        "exact_match_rate": round(c["n_exact"] / len(results), 4)
                              if results else 0.0,
        "metrics": metrics,
    }

    os.makedirs(os.path.dirname(os.path.abspath(args.output)), exist_ok=True)
    with open(args.output, "w", encoding="utf-8") as f:
        for row in results:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
        f.write(json.dumps(summary, ensure_ascii=False) + "\n")

    print("\n" + "=" * 20 + f" {args.version} stage={args.stage} Test Summary "
          + "=" * 20)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    print(f"\nResults saved: {args.output}")


if __name__ == "__main__":
    main()
