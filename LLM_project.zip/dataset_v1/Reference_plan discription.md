# LLM.pdf Summary: Paper Objectives and Implementation Steps

> Source: *Error Typing for Smarter Rewards: Improving Process Reward Models with Error-Aware Hierarchical Supervision* (arXiv:2505.19706, May 2025)
> Authors: Tej Deep Pala, Panshul Sharma (Singapore University of Technology and Design), Amir Zadeh, Chuan Li (Lambda Labs), Soujanya Poria
> Code: <https://github.com/declare-lab/PathFinder-PRM>

---

## 1. Objective of the Paper

### 1. Problem to Solve

Large language models are prone to hallucinations and subtle logical errors in multi-step reasoning tasks such as mathematics:

- **Outcome Reward Models (ORMs)** can only judge whether the final answer is correct; they cannot catch **mid-step errors** that cause the reasoning to go astray;
- Existing **Process Reward Models (PRMs)** can score each step, but they mix two things into a single prediction: "whether this step contains an error" (error detection) and "how helpful this step is for solving the problem" (path optimality). The two types of signals dilute each other, resulting in weak detection of **fine-grained errors** such as redundancy, circular reasoning, and inconsistency (performance drops markedly on PRMBench).

### 2. Core Hypothesis and Goal

> **Hypothesis**: Decoupling "error detection" and "reward estimation" into two serial subtasks—first explicitly identifying the error type, then computing the step reward conditioned on it—works better than predicting the reward directly.

To this end, the paper proposes **PathFinder-PRM**: a hierarchical, error-type-aware discriminative PRM that, for each solution step:

1. First classifies two error categories—**Math Error** (calculation/formula/derivation errors) and **Consistency Error** (contradiction with the problem, prior steps, or known constraints);
2. Then, conditioned on the error labels, estimates the step's **final Correctness reward**.

### 3. Main Results

- Built roughly **400,000** training samples with three-dimensional step labels (math / consistency / correctness) (about 345,000 from PRM800K + about 55,000 from RLHFlow Mistral);
- Achieves SOTA on PRMBench: **PRMScore 67.7** (previous best 65.5), using only about one third of the strongest baseline's data;
- Reward-guided greedy search reaches **prm@8 = 48.3**, 1.5 points above the strongest baseline;
- Ablations show: ① the "two-stage decoupling" is effective (PRMBench +2.8); ② further splitting errors into two sub-types gives a small additional gain (+0.4); ③ adding heterogeneous (weaker-model-generated) data helps further, but gains saturate after scaling to 200,000 samples.

---

## 2. Implementation Steps

### Step 1: Build the Three-Dimensional Labeled Dataset

1. **Data sources**: PRM800K (human-annotated step-level labels, l ∈ {-1, 0, 1}) + RLHFlow's Mistral-PRM-Data (Monte Carlo estimated labels);
2. **Label system**: Each step is annotated with a three-dimensional binary vector c = (math, consistency, correctness):
   - In PRM800K, l=1 (correct and optimal) → (1,1,1); l=0 (correct but suboptimal) → (1,1,0);
   - l=-1 (error) and RLHFlow data without fine-grained labels → automatically annotated by **DeepSeek-R1-Distill-Qwen-32B** following a fixed grading prompt (Appendix D: output 0/1 after checking calculation, formulas, consistency, redundancy, etc. one by one);
3. **Consistency filtering**: Remove samples whose automatic labels contradict the human/Monte Carlo labels (e.g., human-labeled as error but the 3D vector is all 1's), yielding about 400,000 trajectories in total.

### Step 2: Model Design

1. **Base model**: Qwen2.5-Math-7B-Instruct (a model strong in mathematics is better suited to serve as a PRM);
2. **Do not replace the model head**: Keep the original LM structure; add two special tokens `<+>` (correct) and `<->` (error) to the tokenizer as labels;
3. **Hierarchical two-stage structure**:
   - Stage 1: predict the step's math-error label M and consistency-error label C;
   - Stage 2: append M and C as known conditions to the input, then predict the correctness label R; the probability of `<+>` at R is the step's reward.

### Step 3: Training

- **Training objective**: Each sample is organized as two forward passes—the error-detection objective ("Math: <+>/<->, Consistency: <+>/<->") and the reward-estimation objective ("Correctness: <+>/<->" after appending the known error labels). **Cross-entropy is computed only at the label token positions**;
- **Hyperparameters (Appendix E)**: bf16, FlashAttention-2, batch 2 × gradient accumulation 32, learning rate 1e-5, cosine schedule, 4 epochs, warmup 0.1, gradient clipping 1.0, gradient checkpointing;
- Two variants are trained: PathFinder-PRM-7B (full 400,000) and PathFinder-PRM-7B-PRM800K (only the PRM800K subset, about 345,000).

### Step 4: Inference (Two Forward Passes, Appendix C)

1. **First forward pass**: Input `[PRM input], Math: <mask>, Consistency: <mask>`; decode the two error labels simultaneously at the two mask positions (predicted in parallel within one forward pass to avoid the latter label being autoregressively affected by the former);
2. **Second forward pass**: Substitute the predicted labels into the text; input `[PRM input], Math: predicted, Consistency: predicted, Correctness: <mask>`; take the softmax probability of `<+>` at the correctness mask position as the step's reward;
3. This design avoids label-to-label dependency leakage and achieves a modular separation of supervision signals.

### Step 5: Evaluation

1. **Step-level error detection**: ProcessBench (3,400 problems, locate the first erroneous step) and PRMBench (6,216 problems, 83,456 step labels, covering nine fine-grained dimensions across the three broad categories of conciseness/reliability/sensitivity); metrics are F1 and PRMScore, a composite of positive and negative F1;
2. **Downstream tasks**: Using Qwen2.5-7B-Instruct as the generator model and the PRM to score step by step for **reward-guided greedy search**, compare prm@8 on AIME24, AMC23, MATH, OlympiadBench, CollegeMath, and Minerva MATH;
3. **Ablations**: Train controls that remove the "two-stage decoupling" (predict correctness only) and remove the "error classification" (merge into a single error label); run data-scale experiments (50,000 → 200,000 RLHFlow samples) to verify the benefit of data expansion and its saturation point.

---

## 3. Relationship to Our Project (Brief)

Our research (see LLM proposal.pdf) builds on this work by **further refining the error taxonomy**: splitting the 2 error types into 4 types (Calculation / Method / Prior-step consistency / Domain consistency), to test whether the trend "finer granularity brings greater gains" continues or reverses into saturation. Training data, the two-stage structure, and the evaluation benchmark (PRMBench) all follow the paper's design; the only changes are that the base model is replaced with Qwen2.5-Math-1.5B-Instruct and fine-tuned with QLoRA (due to limited compute).

## Question:
Does this paper ask the LLM to answer questions while also producing judgments, or does it use a separate deep learning model to classify the answers already produced by an LLM?

    >> It is the latter: **a separate "grading" model (PathFinder-PRM) is trained independently to classify and score the solutions step by step that other LLMs have already generated.** Answering and error-checking are two models in a serial pipeline:

    1. **Answer model (Generator)**: Any LLM (the paper's downstream experiments use Qwen2.5-7B-Instruct) generates the solution to the math problem. PathFinder-PRM **never solves problems itself**;
    2. **Error-checking model (PathFinder-PRM)**: An independent model (fine-tuned from Qwen2.5-Math-7B-Instruct), whose input is "problem + the first t steps of a generated solution" and whose output is only a few label tokens (the `<+>`/`<->` for Math / Consistency / Correctness) and their probabilities—that is, it classifies for each step "whether there is an error and which type"; the probability of the correctness label is the reward score for the step.

    Several easily confused points:

    - **"Fine-tuning an LLM" ≠ "letting the LLM answer and judge at the same time"**: PathFinder-PRM is obtained by fine-tuning an LLM (Qwen2.5-Math-7B), but after fine-tuning it only discriminates and no longer generates. It keeps the LM structure only to reuse the model's language understanding and output probabilities;
    - **The training data is also "other people's solutions"**: The 400,000 training samples come from solutions generated by GPT-4 (PRM800K) and Mistral-class models (RLHFlow), with error types annotated by humans / the DeepSeek model. The grading model learns "what errors look like";
    - **How they connect in practice**: The two cooperate in downstream tasks—the answer model generates a solution → PathFinder-PRM scores it step by step → the scores guide search (if a step scores low, backtrack and regenerate)—thereby improving the answer model's own accuracy (the prm@8 metric). This is the typical use of a PRM: improve output quality with an external "judge" without modifying the generator model.

    For our project: we adopt the same two-stage structure, only replacing the grading model with Qwen2.5-Math-1.5B (local) or qwen3-1.7b (online), and refining the error taxonomy from 2 classes to 4 classes.

### My conclusion
  As described above, do we only need to write a program to train a PathFinder-PRM-like model? Is that right? Briefly introduce the PathFinder-PRM model—can we continue training or fine-tuning on top of that model? Please give a proposal and concrete implementation steps. Also, does the existing data need to be converted to fit our model training/fine-tuning?

    >> 1. "Is it enough to train a PathFinder-PRM-like model?" — Yes. There is no need to train an answer model; only the grading model needs to be trained. The actual work = a data preprocessing script + a QLoRA training script + a two-forward-pass inference script; the detailed design is in the two proposal documents.

    2. "Can we continue fine-tuning on top of PathFinder-PRM?" — Technically yes (weights are open-sourced: declare-lab/PathFinder-PRM-7B), but it is not recommended as the main line: ① it has already been trained on 400,000 samples with the 2-class label taxonomy, and continuing training from it would break the controlled design where "label granularity is the only variable"; ② 7B exceeds the comfortable QLoRA range of a free T4; ③ the label semantics are already bound to the 2-class system. The main line remains training cleanly from Qwen2.5-Math-1.5B per the proposal; warm-starting can be kept as an additional experiment.


====

## Question 2:
Since we no longer need to fine-tune an LLM—or rather, our work is only to discriminate the LLM's answers—why do you still fine-tune the local/online Qwen models? Can't we just build a deep learning model (or some other model) similar to PathFinder-PRM?

>> **Clarification: "fine-tuning Qwen" and "building a PathFinder-PRM-like discriminative model" are the same thing, not an either/or choice.**

### 1. Conceptual clarification

Your understanding points in the right direction—the deliverable is indeed a model that **only discriminates and does not answer questions**. But the key fact is:

> **PathFinder-PRM is not an independent "deep learning classifier" trained from scratch; it is exactly the product of "fine-tuning the Qwen2.5-Math-7B LLM".**

"Fine-tuning Qwen" is the means; "obtaining the grading model" is the result—two sides of the same process. Specifically:

- Take a pretrained Qwen model (at this point a general-purpose answer-generating LLM);
- Fine-tune it with the "problem + solution steps + error-type labels" data (i.e., dataset_v1);
- After fine-tuning, it becomes a grading model that only outputs `<+>/<->` labels—**this is how PathFinder-PRM is born, and the process we need to reproduce**.

### 2. Why an LLM backbone is mandatory rather than training a classifier from scratch

In theory an encoder such as BERT/DeBERTa or a network trained from scratch could do step classification, but it is infeasible or performs poorly:

1. **Grading requires deep mathematical and language understanding**: To detect that "1000/10=30 is a calculation error" or "1000/5=200 uses the wrong quantity from the problem statement", the model must first understand mathematical reasoning itself. Only an LLM pretrained on large-scale corpora has this ability; reaching equivalent understanding from scratch would require massive data and compute;
2. **Fine-tuning is extremely cheap**: The pretrained model already "knows math"; we only need LoRA/QLoRA to adjust about 0.1%–1% of the parameters to teach it to "express judgments with labels". 2,330 samples can be fully trained on a free T4;
3. **Output probabilities are naturally rewards**: The LLM outputs the softmax probability of each token, and `P(<+>)` is directly the step score—no extra scoring head is needed;
4. **Alignment with the paper**: Our study tests the single variable of error-label refinement, so the model structure and training method must match the original paper; label granularity is the only allowed difference.

### 3. What fine-tuning means here precisely

Fine-tuning is **not** making Qwen better at solving problems—the training data contains no signal of "teaching the model to solve problems"; every sample is "someone else's solution + error labels for that step". After fine-tuning, the model's behavior shifts from "wanting to solve upon seeing a problem" to "outputting a judgment label upon seeing a solution". Problem-solving ability may even degrade, but that doesn't matter—grading is its sole responsibility; answering is left to other models.

### 4. Proposal

**Fine-tune Qwen2.5-Math-1.5B-Instruct with QLoRA to turn it into a four-class error grading model (our "PathFinder-PRM-4class")**:

- Input: the problem + the first t steps of a generated solution;
- Output: four `<+>/<->` labels for Calculation / Method / Prior-step consistency / Domain consistency + a Correctness judgment (two forward passes);
- The `<+>` probability of Correctness = the step's reward score;
- Optional controls: train 1class / 2class versions with the same pipeline to verify the benefit of finer labels.

### 5. Implementation steps

1. **Prepare the backbone**: Download Qwen2.5-Math-1.5B-Instruct (HuggingFace, about 3 GB);
2. **Prepare the data**: `dataset_v1/prm_4class.jsonl`; split out a validation set of 93 problems according to `val_question_ids.json`, with the remaining 2,237 problems for training;
3. **Preprocessing**: register `<+>/<->` in the tokenizer (mapped to unused tokens), organize each sample into the two-stage input, and mark label mask positions (see §6/§7 of the *Qwen Local Model Fine-Tuning Proposal* document for scripts);
4. **Training (QLoRA on Colab/Kaggle T4)**: load the backbone with 4-bit quantization → attach LoRA (r=16, alpha=32, target all linear layers) → lr 1.4e-4, cosine, 3 epochs, batch 8×2, seed 42 → loss only at label token positions;
5. **Model selection**: compare val loss and per-dimension accuracy of checkpoints on the validation set;
6. **Inference script**: two forward passes—first predict the four error labels in parallel, then substitute them to predict Correctness, outputting per-step labels + probability scores;
7. **Evaluation**: compute PRMScore on a fixed subset of PRMBench (seed=42), compare with the 1/2class controls to verify whether finer granularity helps;
8. **Deliverables**: LoRA adapter weights (tens of MB) + inference script; at use time, merge with the backbone or load dynamically.

In one sentence: **It is not "no LLM fine-tuning", but "only LLM fine-tuning"—the fine-tuned LLM is the discriminative model itself that we want.**

### My decision
 1. Do not consider any work related to large generative models; I only want to discriminate the results produced by large models. Any further discussion of LLM fine-tuning techniques is prohibited.
 2. Recommend a model usable for classifying the error types of large-model computed results (similar to PathFinder-PRM), then train and test it using the existing dataset_v1.
 3. Put the proposal and operating steps below in this document, separated by ====.


====

## Proposal: A Multi-Label Error Classifier Based on DeBERTa-v3-base

> Note: This proposal completely departs from LLM fine-tuning. It uses a lightweight pretrained language encoder (DeBERTa) + a classification head to train a step-level error-type discriminator directly on the 4class data in dataset_v1.

### 1. Model Selection

**Recommended model: DeBERTa-v3-base (Microsoft, 86M parameters)**

| Feature | Description |
|---|---|
| Type | Bidirectional encoder (encoder-only), non-generative |
| Parameters | 86M (base) or 304M (large); CPU inference possible |
| Input length | 512 tokens (long math text must be truncated) |
| Output | 4-dimensional sigmoid probabilities for the four error types |
| Advantages | Strong pretrained language understanding, mature classification ecosystem, fast training (converges within 10 minutes on a T4) |
| Differences from PathFinder-PRM | ① Predicts 4 labels in parallel instead of autoregressively; ② Outputs classification probabilities instead of token-probability rewards; ③ Cannot perform "two-stage" conditional inference (stage 2 conditioned on stage 1); all 4 labels are predicted simultaneously |

**Why not BERT/RoBERTa**: DeBERTa-v3's pretraining task (replaced token detection) makes it better than standard BERT at understanding math symbols and LaTeX expressions, which has been validated on public PRM-related benchmarks.

**Handling the 512-token limit**: 90% of the stage-1 samples in dataset_v1 are within 600 tokens (problem + all prior steps + current step). Truncation strategy: keep the problem (essential) + current step (essential) + at most 2 prior steps; when exceeding the limit, discard starting from the earliest steps. This has little impact on Domain consistency and Calculation judgments (which mainly depend on the problem and the current step itself), but may slightly affect Prior-step consistency.

### 2. Data Conversion

Each stage=1 record in dataset_v1/prm_4class.jsonl must be converted into an encoder-ready (text, labels) pair:

**Input text format**:
```
Question: {question_text}
Previous Steps: {step_1} | {step_2} | ... (keep at most the 2 most recent steps; truncate beyond)
Current Step: {current_step_text}
```

**Label vector** (parsed from the end of the assistant content):
```python
labels = [
    1 if "Calculation: <->" else 0,      # 0=no error, 1=error
    1 if "Method: <->" else 0,
    1 if "Prior-step consistency: <->" else 0,
    1 if "Domain consistency: <->" else 0,
]
```

**Data volume**:
- Total stage-1 samples: 2,330 (1,165 erroneous steps + 1,165 correct/suboptimal steps)
- Validation split by the 93 question_ids in `val_question_ids.json` (about 186 stage-1 samples); the remaining about 2,144 samples for training

**Key issue: extreme class imbalance**

| Error type | Number of positive samples (label=1) at stage 1 | Share |
|---|---:|---:|
| Calculation | about 400+ | ~17% |
| Method | about 300+ | ~13% |
| Prior-step consistency | about 75 | ~3% |
| Domain consistency | about 200+ | ~9% |

Prior-step has very few positive samples; direct training will be heavily biased toward predicting 0. Countermeasures:
- Use **Focal Loss** instead of BCE to down-weight easy negatives;
- Or train one binary classifier per class (4 independent models), with oversampling + stronger regularization for Prior-step.

### 3. Implementation Steps

**Step 1: Environment setup**
```bash
pip install transformers datasets torch scikit-learn
```

**Step 2: Data conversion script** (outputs HuggingFace Dataset format)
- Read `prm_4class.jsonl` and filter `stage == 1`;
- Parse `labels[0].content` to extract Question, Previous Steps, and Current Step;
- Parse the four label types at the end of `labels[1].content` to produce a 4-dimensional binary vector;
- Split train/val according to `val_question_ids.json`;
- Save as `dataset_v1/deberta_train.jsonl` and `dataset_v1/deberta_val.jsonl`.

**Step 3: Model construction**
```python
from transformers import DebertaV2Tokenizer, DebertaV2Model
import torch.nn as nn

class ErrorTypeClassifier(nn.Module):
    def __init__(self):
        super().__init__()
        self.deberta = DebertaV2Model.from_pretrained("microsoft/deberta-v3-base")
        self.classifier = nn.Sequential(
            nn.Linear(768, 256),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(256, 4),    # 4 error classes
        )
    
    def forward(self, input_ids, attention_mask):
        outputs = self.deberta(input_ids=input_ids, attention_mask=attention_mask)
        pooled = outputs.last_hidden_state[:, 0, :]  # [CLS] token
        logits = self.classifier(pooled)
        return logits  # (batch, 4)
```

**Step 4: Training**
- Optimizer: AdamW, lr=2e-5, weight_decay=0.01;
- Loss: Focal Loss (γ=2.0) or weighted BCE (positive weights set inversely proportional to class frequency);
- Batch size: 16 (fits T4), epochs: 5–10 (early stopping patience=2);
- Schedule: linear warmup 10% + cosine decay;
- seed=42, consistent with the paper.

**Step 5: Inference**
```python
# Input: one problem + one solution step
# Output: 4 probabilities + binary decisions (default threshold 0.5; Prior-step can be lowered to 0.3 for higher recall)
probs = torch.sigmoid(logits)  # (4,) in [0,1]
preds = (probs > threshold).int()
# probs can be viewed as "the likelihood that this step contains a certain type of error"; higher means more suspicious
```

**Step 6: Evaluation**

| Metric | Description |
|---|---|
| Per-class P/R/F1 | Report F1 separately for Calculation / Method / Prior-step / Domain |
| Macro-F1 | Average of the four F1s, reflecting overall balance |
| PRMScore (approximate) | Map the decisions back to `<+>/<->` and compute per the paper's formula on a PRMBench subset (an additional adapter script needed) |

Pay special attention: **the F1 of Prior-step consistency is the core observation metric**—if it is significantly above the random baseline, it shows that even without an LLM, a lightweight model can learn "contradiction with prior steps" patterns; if it is close to 0, this error type truly requires deep reasoning and the non-LLM approach has a hard boundary here.

### 4. Limitations (honestly stated)

1. **No autoregressive conditional inference**: PathFinder-PRM's stage 2 (predicting Correctness conditioned on error labels) cannot be reproduced; DeBERTa can only output the 4 labels in parallel and cannot model "how the probability of Correctness changes given that Calculation has an error";
2. **Long-text truncation**: Extremely long solutions (>512 tokens) lose prior-step information, hurting Prior-step consistency judgments;
3. **No math priors**: DeBERTa has no explicit encoding of arithmetic facts like "1000/10=100"; Calculation errors can only be learned through textual pattern matching (e.g., the contextual inconsistency between "30" and "100"), and it cannot truly "do arithmetic" like an LLM;
4. **The output is not a standard reward**: PathFinder-PRM's `<+>` probability can be used directly as the reward in beam-search-like generation strategies; DeBERTa's sigmoid output is a classification confidence—the two have different semantics and cannot be directly swapped into the generation-search pipeline.

### 5. Relationship to the LLM-based PRM

This proposal is a **functionally degraded version** of PathFinder-PRM:
- Same input ("problem + steps") and same output (four error-type judgments);
- But weaker in reasoning depth, conditional probability modeling, and long-text handling;
- **Applicable scenarios**: rapid prototyping, low-resource deployment (runs on CPU), or serving as a "fast screening layer" for the LLM-based PRM (use DeBERTa to first filter out clearly correct steps, then send suspicious steps to the LLM for fine-grained judgment).

### 6. Quick-start code skeleton

```python
# train_deberta_prm.py skeleton (to be completed)
from datasets import load_dataset
from transformers import (
    DebertaV2Tokenizer, DebertaV2Model,
    Trainer, TrainingArguments
)
import torch, torch.nn as nn
import numpy as np
from sklearn.metrics import f1_score

# 1. Load converted data
train_ds = load_dataset("json", data_files="dataset_v1/deberta_train.jsonl", split="train")
val_ds   = load_dataset("json", data_files="dataset_v1/deberta_val.jsonl", split="train")

# 2. Tokenizer
tokenizer = DebertaV2Tokenizer.from_pretrained("microsoft/deberta-v3-base")

def preprocess(examples):
    tokens = tokenizer(
        examples["text"], truncation=True, padding="max_length", max_length=512
    )
    tokens["labels"] = examples["labels"]  # list of 4 ints
    return tokens

train_ds = train_ds.map(preprocess, batched=True)
val_ds   = val_ds.map(preprocess, batched=True)

# 3. Model (see ErrorTypeClassifier above)
model = ErrorTypeClassifier()

# 4. Focal Loss training objective
class FocalLoss(nn.Module):
    def __init__(self, gamma=2.0, pos_weight=None):
        super().__init__()
        self.gamma = gamma
        self.bce = nn.BCEWithLogitsLoss(pos_weight=pos_weight)
    def forward(self, logits, targets):
        bce_loss = self.bce(logits, targets.float())
        p = torch.sigmoid(logits)
        pt = p * targets + (1 - p) * (1 - targets)
        focal = ((1 - pt) ** self.gamma * bce_loss).mean()
        return focal

# 5. Training (using the HuggingFace Trainer)
training_args = TrainingArguments(
    output_dir="./deberta_prm",
    num_train_epochs=10,
    per_device_train_batch_size=16,
    learning_rate=2e-5,
    weight_decay=0.01,
    evaluation_strategy="epoch",
    save_strategy="epoch",
    load_best_model_at_end=True,
    metric_for_best_model="eval_macro_f1",
    seed=42,
)

def compute_metrics(eval_pred):
    logits, labels = eval_pred
    probs = 1 / (1 + np.exp(-logits))
    preds = (probs > 0.5).astype(int)
    macro_f1 = f1_score(labels, preds, average="macro", zero_division=0)
    return {"macro_f1": macro_f1}

trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=train_ds,
    eval_dataset=val_ds,
    compute_metrics=compute_metrics,
)
trainer.train()
```

### 7. Summary

| Dimension | This proposal (DeBERTa) | PathFinder-PRM (LLM fine-tuning) |
|---|---|---|
| Training data | 2,330 samples are enough | 400,000 samples |
| Training cost | Free T4 GPU, 10 minutes | Hours on a T4 (QLoRA) or A100 (full fine-tuning) |
| Inference cost | Real-time on CPU | GPU required; the 7B model has high latency |
| Grading depth | Text pattern matching | Genuine understanding of math reasoning |
| Conditional inference | None (4 labels in parallel) | Yes (serial two stages) |
| Output reward | Classification confidence | Standard token probability |
| Applicable scenarios | Rapid validation, low-resource deployment | Production-grade PRM, generation-search pipelines |

**Recommendation**: First use this proposal to get the end-to-end pipeline running within 2 hours to verify whether data quality is sufficient for the model to learn error patterns; if the F1 for Prior-step / Domain classes is too low (<0.3), then consider introducing the LLM-based approach as a comparison or upgrade.
